/*********************************************************************************************************//**
 * @file    iap_handler.h
 * @version $Rev:: 605          $
 * @date    $Date:: 2025-06-16 #$
 * @brief   The header file of ISP/IAP handler.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __IAP_HANDLER_H
#define __IAP_HANDLER_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------------------------------------*/
#include "middleware/uart_module.h"

/* Exported constants --------------------------------------------------------------------------------------*/
#define ISPIAP_ERASE_PAR_MASS_ERASE     0x0A
#define ISPIAP_ERASE_PAR_PAGE_ERASE     0x08
#define ISPIAP_FLASH_PAR_VERIFY         0x00
#define ISPIAP_FLASH_PAR_PROGRAM        0x01
#define ISPIAP_FLASH_PAR_READ           0x02
#define ISPIAP_FLASH_PAR_BLANK          0x03
#define ISPIAP_RESRT_PAR_RESET_TO_AP    0x00
#define ISPIAP_RESRT_PAR_RESET_TO_IAP   0x01

#define ISPIAP_CMD_ERROR                (0)
#define ISPIAP_CMD_OK                   (1)
#define ISPIAP_CMD_TIMEOUT              (2)

/* Exported macro ------------------------------------------------------------------------------------------*/
#define ISPIAP_DiscardReadBuffer()      UARTM_DiscardReadBuffer(UARTM_CH0)

/* Global function prototypes ------------------------------------------------------------------------------*/
/* Exported variables --------------------------------------------------------------------------------------*/
#if defined(__ARMCC_VERSION)   // Keil
#define AP_CODE_SIZE                  (Image$$AP$$Length)
extern void AP_CODE_SIZE;
#define GET_AP_CODE_SIZE    ((uint32_t)&AP_CODE_SIZE)
#elif defined(__GNUC__)        // HT32-IDE
extern unsigned char AP_CODE_SIZE_START;
extern unsigned char AP_CODE_SIZE_END;
#define GET_AP_CODE_SIZE    ((uint32_t)(&AP_CODE_SIZE_END - &AP_CODE_SIZE_START -4))
#endif
/* Exported functions --------------------------------------------------------------------------------------*/
void ISPIAP_UartInit(void);

u32 ISPIAP_Handler(void);

u32 ISPIAP_Reset(u32 uMode);
u32 ISPIAP_Info(u8* buffer);
u32 ISPIAP_Erase(u32 type, u32 saddr, u32 eaddr);
u32 ISPIAP_Blank(u32 saddr, u32 eaddr);
u32 ISPIAP_Porgram(u32 type, u32 saddr, u32 totallen);
u32 ISPIAP_WriteVersion(u32 type, u32 VerAddr, u8* version, u32 length);
u32 ISPIAP_ReadFlash(u32 saddr, u32 eaddr, u8 *buffer);
u32 ISPIAP_CRC(u32 saddr, u32 length, u16 *crc);
u32 ISPIAP_Exit(void);

#ifdef __cplusplus
}
#endif

#endif
