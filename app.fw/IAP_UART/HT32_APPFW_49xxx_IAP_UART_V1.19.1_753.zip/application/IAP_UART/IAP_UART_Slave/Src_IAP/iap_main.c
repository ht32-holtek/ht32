/*********************************************************************************************************//**
 * @file    IAP_UART/IAP_UART_Slave/Src_IAP/iap_main.c
 * @version $Rev:: 604          $
 * @date    $Date:: 2025-06-16 #$
 * @brief   The main program of HID IAP example.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "middleware/uart_module.h"
#include "iap_handler.h"
#include "iap_config.h"

/* Dependency check ----------------------------------------------------------------------------------------*/
#if defined(__HT32F490x1_H)
#define MIN_HT32_FWLIB_VER              (0x01001002) //0xmmnnnrrr -> Vm.n.r
#define MIN_HT32_FWLIB_SVN              (0x99)
#endif
#if defined(__HT32F491x3_H)
#define MIN_HT32_FWLIB_VER              (0x01000006) //0xmmnnnrrr -> Vm.n.r
#define MIN_HT32_FWLIB_SVN              (0x154)
#endif
#if defined(__HT32F493x5_H)
#define MIN_HT32_FWLIB_VER              (0x01001009) //0xmmnnnrrr -> Vm.n.r
#define MIN_HT32_FWLIB_SVN              (0x152)
#endif
#include "ht32_dependency.h" // Not exist means the version of HT32 Firmware Library is older than the module required.

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_UART IAP UART
  * @{
  */

/** @addtogroup IAP_UART_Slave IAP UART Slave
  * @{
  */

/** @addtogroup IAP_UART_Slave_IAP IAP Example
  * @{
  */


/* Private function prototypes -----------------------------------------------------------------------------*/
void SysTick_Configuration(void);
void UART_Configuration(void);

#if (IAP_BLINKING_LED_EN == 1)
void IAPLED_Configuration(void);
#endif

/* Global variables ----------------------------------------------------------------------------------------*/
#if (IAP_TIMEOUT_EN == 1)
s32 gIAPTimeout = IAP_TIMEOUT;
#endif
#if (IAP_DOUBLE_RESET_EN == 1)
s32 gDoubleTimeout = IAP_DOUBLE_TIMEOUT;
#endif
#if (IAP_BLINKING_LED_EN == 1)
s32 gLEDBlink = IAP_BLINKING_LED_FRQ;
#endif

__ALIGN4 u8 guIAPCmdBuffer[64];
vs32 gIAPCmdTimeout = IAP_CMD_TIMEOUT_DISABLE;
u8 guIAPReceiveFirstBytes = FALSE;

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{
  system_clock_config();

  #if (IAP_DEBUG_MODE == 1)
  uart_print_init(115200);
  #endif

  IAPUser_BootProcess();

  SysTick_Configuration();

  IAP_Init();

  #if (EXT_FLASH_ENABLE == 1)
  #if 0
  /* !!! NOTICE !!!
     Notice that External Flash is not yet supported.
  */
  if (SPI_FLASH_Init() == TRUE)
  {
    SPI_FLASH_WriteStatus(0x00);
  }
  #endif
  #endif

  #if (USER_CMD_DEMO == 1)
  ht32_led_init(LED2);
  ht32_led_init(LED3);
  ht32_led_init(LED4);
  ht32_led_off(LED2);
  ht32_led_off(LED3);
  ht32_led_off(LED4);
  #endif

  #if (IAP_BLINKING_LED_EN == 1)
  IAPLED_Configuration();
  #endif

  UART_Configuration();

  while (1)
  {
    IAPUser_CmdProcess();
  }
}

/*********************************************************************************************************//**
  * @brief  IAP User level boot process.
  * @retval None
  ***********************************************************************************************************/
void IAPUser_BootProcess(void)
{
  #if 0
  /* !!! NOTICE !!!
        Modify it if you want to use another GPIO pin.
  */
  /*--------------------------------------------------------------------------------------------------------*/
  /* Example that using GPIO to force the IAP mode.                                                         */
  /* GPIO = 0: Normal boot flow, GPIO = 1: IAP mode                                                         */
  /*--------------------------------------------------------------------------------------------------------*/
  gpio_init_type  gpio_init_struct = {0};

  crm_periph_clock_enable(CRM_GPIOA_PERIPH_CLOCK, TRUE);
  gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
  gpio_init_struct.gpio_out_type = GPIO_OUTPUT_PUSH_PULL;
  gpio_init_struct.gpio_mode = GPIO_MODE_INPUT;
  gpio_init_struct.gpio_pins = GPIO_PINS_0;
  gpio_init_struct.gpio_pull = GPIO_PULL_DOWN;
  gpio_init(GPIOA, &gpio_init_struct);
  if(gpio_input_data_bit_read(GPIOA, GPIO_PINS_0) == RESET)
  #endif
  {
    #if (IAP_TIMEOUT_EN == 1)
    if (BOOT_MODE == BOOT_MODE_AP)
    {
      /*----------------------------------------------------------------------------------------------------*/
      /* Start user application when                                                                        */
      /*   1. IO = 1 or                                                                                     */
      /*   2. BOOT_MODE == BOOT_MODE_AP (Default IAP) and                                                   */
      /*----------------------------------------------------------------------------------------------------*/
      BOOT_MODE = 0;
      IAP_JumpToAP(IAP_APFLASH_START);
      #if (IAP_DOUBLE_RESET_EN == 1)
      gDoubleTimeout = -1;
      #endif
    }
    #endif
    #if (IAP_DOUBLE_RESET_EN == 1)
    if (BOOT_MODE != BOOT_MODE_AP)
    {
      if ((crm_flag_get(CRM_NRST_RESET_FLAG) == SET) &&
         (crm_flag_get(CRM_POR_RESET_FLAG) == RESET))
      {
        /* External IO reset.                                                                               */
        if (HARDWAVE_RESET == HARDWAVE_RESET_FIRST)
        {
          /* The second external IO reset.                                                                  */
          HARDWAVE_RESET = 0;
          gDoubleTimeout = -1;
          #if (IAP_TIMEOUT_EN == 1)
          gIAPTimeout = -1;
          #endif
        }
        else
        {
          /* The first external IO reset, stay in IAP mode.                                                 */
          HARDWAVE_RESET = HARDWAVE_RESET_FIRST;
        }
        BOOT_MODE = BOOT_MODE_IAP;
      }
      crm_flag_clear(CRM_POR_RESET_FLAG);
      crm_flag_clear(CRM_NRST_RESET_FLAG);
    }
    #endif
    #if (IAP_TIMEOUT_EN == 0)
    if (BOOT_MODE != BOOT_MODE_IAP)
    {
      /*----------------------------------------------------------------------------------------------------*/
      /* Start user application when BOOT_MODE != BOOT_MODE_IAP (Default AP)                                */
      /*----------------------------------------------------------------------------------------------------*/
      IAP_JumpToAP(IAP_APFLASH_START);
      #if (IAP_TIMEOUT_EN == 1)
      gIAPTimeout = -1;
      #endif
      #if (IAP_DOUBLE_RESET_EN == 1)
      gDoubleTimeout = -1;
      #endif
    }
    #endif
  }

  /*--------------------------------------------------------------------------------------------------------*/
  /* Start IAP mode                                                                                         */
  /*   1. IO = 0 or                                                                                         */
  /*   2. BOOT_MODE = BOOT_MODE_IAP                                                                         */
  /*--------------------------------------------------------------------------------------------------------*/

  BOOT_MODE = 0;
}

/*********************************************************************************************************//**
  * @brief  IAP User level reset.
  * @retval None
  ***********************************************************************************************************/
void IAPUser_Reset(void)
{
  /* Confirm the communication is finished.                                                                 */

  gIAPCmdTimeout = IAP_CMD_TIMEOUT_RESET;

  #if 0 // "uart_module.c" SVN >= 525 required
  while (UARTM_IsTxFinished(UARTM_CH0) == FALSE)
  #else
  while (1)
  #endif
  {
    if (gIAPCmdTimeout <= 0)
    {
      break;
    }
  }

  NVIC_DisableIRQ(HTCFG_UARTM0_IRQn);
  NVIC_SystemReset();
}

/*********************************************************************************************************//**
  * @brief  USB User level command process.
  * @retval None
  ***********************************************************************************************************/
void IAPUser_CmdProcess(void)
{
  u32 uResponseLength;
  u32 uRxindex;

  #if (SLAVE_PULL_HANDSHAKE == 1)
  if (guIAPReceiveFirstBytes == FALSE)
  {
    IAP_SlavePullHandshake();
  }
  #endif

  uRxindex = UARTM_GetReadBufferLength(UARTM_CH0);
  if (uRxindex > 0)
  {
    if (guIAPReceiveFirstBytes == FALSE)
    {
      guIAPReceiveFirstBytes = TRUE;
      gIAPCmdTimeout = IAP_CMD_TIMEOUT_BUFFER_RELOAD;
    }
  }

  if (gIAPCmdTimeout == 0)
  {
    /* Timeout, Rest Rxbuffer                                                                               */
    UARTM_DiscardReadBuffer(UARTM_CH0);
    guIAPReceiveFirstBytes = FALSE;
    gIAPCmdTimeout = IAP_CMD_TIMEOUT_DISABLE;
    return;
  }

  if (uRxindex < 64)
  {
    return;
  }

  UARTM_Read(UARTM_CH0, guIAPCmdBuffer, 64);

  uResponseLength = IAP_CMDHandler(guIAPCmdBuffer);

  UARTM_Write(UARTM_CH0, guIAPCmdBuffer, uResponseLength);

  guIAPReceiveFirstBytes = FALSE;
  gIAPCmdTimeout = IAP_CMD_TIMEOUT_DISABLE;
}

/*********************************************************************************************************//**
  * @brief  IAP User level send data.
  * @param  puData: Pointer of dada buffer for write
  * @param  uLength: Write length
  * @retval Total length sent by this function
  ***********************************************************************************************************/
u32 IAPUser_SendData(u8 *puData, u32 uLength)
{
  while (UARTM_GetWriteBufferLength(UARTM_CH0) != 0){};
  return UARTM_Write(UARTM_CH0, puData, uLength);
}

/*********************************************************************************************************//**
  * @brief  SysTick Configuration.
  * @retval None
  ***********************************************************************************************************/
void SysTick_Configuration(void)
{
  #define TIMER_BASE                    (SystemCoreClock * 1 / 1000)  /* 1 ms                               */
  SysTick_Config(TIMER_BASE);
}

/*********************************************************************************************************//**
  * @brief  UART Configuration.
  * @retval None
  ***********************************************************************************************************/
void UART_Configuration(void)
{
  /* !!! NOTICE !!!
     Notice that the local variable (structure) did not have an initial value.
     Please confirm that there are no missing members in the parameter settings below in this function.
  */
  #if !defined(HTCFG_BAUD_RATE)
  #define HTCFG_BAUD_RATE    115200
  #endif
  USART_InitTypeDef USART_InitStructure;
  USART_InitStructure.USART_BaudRate = HTCFG_BAUD_RATE;
  USART_InitStructure.USART_WordLength = USART_DATA_8BITS;
  USART_InitStructure.USART_StopBits = USART_STOP_1_BIT;
  USART_InitStructure.USART_Parity = USART_PARITY_NONE;
  UARTM_Init(UARTM_CH0, &USART_InitStructure, 0);
}

#if (IAP_BLINKING_LED_EN == 1)
/*********************************************************************************************************//**
  * @brief  IAP LED Blinking Configuration.
  * @retval None
  ***********************************************************************************************************/
void IAPLED_Configuration(void)
{
  gpio_init_type gpio_init_struct;

  crm_periph_clock_enable(HTCFG_BLINKING_LED_CLK, TRUE);
  gpio_default_para_init(&gpio_init_struct);

  /* configure the gpio */
  gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
  gpio_init_struct.gpio_out_type = GPIO_OUTPUT_PUSH_PULL;
  gpio_init_struct.gpio_mode = GPIO_MODE_OUTPUT;
  gpio_init_struct.gpio_pins = HTCFG_BLINKING_LED_GPIO_PIN;
  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
  gpio_init(HTCFG_BLINKING_LED_ID, &gpio_init_struct);

  gpio_bits_set(HTCFG_BLINKING_LED_ID, HTCFG_BLINKING_LED_GPIO_PIN);
}
#endif

#if (HT32_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Report both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
     Example: printf("Parameter Error: file %s on line %d\r\n", filename, uline);
  */

  while (1)
  {
  }
}
#endif


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
