;********************************************************************************
;* @file        target_ap.s
;* @version     $Rev:: 1097         $
;* @date        $Date:: 2015-11-19 #$
;* @brief       Include AP image
;*
;* @note        Copyright (C) Holtek Semiconductor Inc. All rights reserved.
;*
;* <h2><center>&copy; COPYRIGHT Holtek</center></h2>
;*
;********************************************************************************
;*----------- <<< Use Configuration Wizard in Context Menu >>> ------------------
;********************************************************************************

TARGET_CHIP         EQU     0

USER_DEFINE         EQU     0
HT32F1653_54_55_56  EQU     1
HT32F12365_66       EQU     2
HT32F12345          EQU     3
HT32F12364          EQU     16

;============================================================================================================
; !!! NOTICED !!!
; Use plaintext image when #define ARC4_DECRYPTION_EN (0) in "iap_config.h" of IAP_UART_Slave (AP_Plaintext.bin or AP_xxxxx_Plaintext.bin)
; Use encrypted image when #define ARC4_DECRYPTION_EN (1) in "iap_config.h" of IAP_UART_Slave (AP_Encrypt.bin or AP_xxxxx_Encrypt.bin)
;============================================================================================================

        AREA    TARGET_AP, DATA, READONLY

          IF (TARGET_CHIP=USER_DEFINE)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F1653_54_55_56)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_1654_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_1654_Encrypt.bin

            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_1656_Plaintext.bin
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_1656_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F12345)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_12345_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_12345_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F12365_66)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_12366_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_12366_Encrypt.bin
          ENDIF


        AREA    TARGET_DIGEST, DATA, READONLY

          IF (TARGET_CHIP=USER_DEFINE)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F1653_54_55_56)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_1654_Encrypt_digest.bin

            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_1656_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F12345)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_12345_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F12365_66)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_12366_Encrypt_digest.bin
          ENDIF


        END
