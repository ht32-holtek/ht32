/*********************************************************************************************************//**
 * @file    IAP_UART/IAP_UART_Slave/Src_AP/main.c
 * @version $Rev:: 672          $
 * @date    $Date:: 2025-07-01 #$
 * @brief   The main program of UART IAP example.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "middleware/uart_module.h"
#include "ap_handler.h"
#include "ap_config.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_UART IAP UART
  * @{
  */

/** @addtogroup IAP_UART_Slave IAP UART Slave
  * @{
  */

/** @addtogroup IAP_UART_Slave_AP AP Example
  * @{
  */


/* Private function prototypes -----------------------------------------------------------------------------*/
void SysTick_Configuration(void);
void UART_Configuration(void);
void ShowTestMenu(void);
void FunctionHandler(u32 uCommand);

void IAPUser_ShowVersion(void);

/* Global variables ----------------------------------------------------------------------------------------*/
__ALIGN4 u8 guIAPCmdBuffer[64];
vs32 gIAPCmdTimeout = IAP_CMD_TIMEOUT_DISABLE;
u8 guIAPReceiveFirstBytes = FALSE;

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{
  #if (HTCFG_STACK_USAGE_ANALYSIS == 1)
  /* !!! NOTICE !!!
     Please update the Keil HT32 PACK and HT32 Firmware Library to the latest version to make sure the
     Stack Usage Analysis function works properly.
  */
  /*
    Set HTCFG_STACK_USAGE_ANALYSIS as 1 in the "ht32xxxxxx_conf.h" to enable Stack Usage Analysis feature.
    This feature is only applicable to the Keil MDK-ARM. Please call the "StackUsageAnalysisInit()" function
    in the begin of the "main()".
    The "StackUsageAnalysisInit()" parameter shall be the start address of the vector table.
    Under Keil Debug mode, tick "View > Watch Window > HT32 Stack Usage Analysis" to show the stack usage
    information. Those information is only valid after calling "StackUsageAnalysisInit()" function.
  */
  StackUsageAnalysisInit(IAP_APFLASH_START);
  #endif

  NVIC_SetVectorTable(NVIC_VECTTABLE_FLASH, IAP_APFLASH_START);     /* Set the Vector Table Offset          */

  RETARGET_Configuration();

  HT32F_DVB_LEDInit(HT_LED1);
  HT32F_DVB_LEDInit(HT_LED2);
  HT32F_DVB_LEDInit(HT_LED3);

  SysTick_Configuration();

  UART_Configuration();

  AP_Init();

  IAPUser_ShowVersion();
  ShowTestMenu();

  while (1)
  {

    IAPUser_CmdProcess();

    if (USART_GetFlagStatus(RETARGET_USART_PORT, USART_FLAG_RXDR) == SET)
    {
      u32 input;
      input = getchar();
      printf("\r\n\r\n");
      FunctionHandler(input);
      ShowTestMenu();
    }

  }
}

/*********************************************************************************************************//**
  * @brief  IAP User level reset.
  * @retval None
  ***********************************************************************************************************/
void IAPUser_Reset(void)
{
  /* Confirm the communication is finished.                                                                 */

  gIAPCmdTimeout = IAP_CMD_TIMEOUT_RESET;

  #if 0 // "uart_module.c" SVN >= 525 required
  while (UARTM_IsTxFinished(UARTM_CH0) == FALSE)
  #else
  while (1)
  #endif
  {
    if (gIAPCmdTimeout <= 0)
    {
      break;
    }
  }

  NVIC_DisableIRQ(HTCFG_UART_IRQn);
  NVIC_SystemReset();
}

/*********************************************************************************************************//**
  * @brief  USB User level command process.
  * @retval None
  ***********************************************************************************************************/
void IAPUser_CmdProcess(void)
{
  u32 uResponseLength;
  u32 uRxindex;

  #if (SLAVE_PULL_HANDSHAKE == 1)
  if (guIAPReceiveFirstBytes == FALSE)
  {
    AP_SlavePullHandshake();
  }
  #endif

  uRxindex = UARTM_GetReadBufferLength(UARTM_CH0);
  if (uRxindex > 0)
  {
    if (guIAPReceiveFirstBytes == FALSE)
    {
      guIAPReceiveFirstBytes = TRUE;
      gIAPCmdTimeout = IAP_CMD_TIMEOUT_BUFFER_RELOAD;
    }
  }

  if (gIAPCmdTimeout == 0)
  {
    /* Timeout, Rest Rxbuffer                                                                               */
    UARTM_DiscardReadBuffer(UARTM_CH0);
    guIAPReceiveFirstBytes = FALSE;
    gIAPCmdTimeout = IAP_CMD_TIMEOUT_DISABLE;
    return;
  }

  if (uRxindex < 64)
  {
    return;
  }

  UARTM_Read(UARTM_CH0, guIAPCmdBuffer, 64);

  uResponseLength = IAP_CMDHandler(guIAPCmdBuffer);

  UARTM_Write(UARTM_CH0, guIAPCmdBuffer, uResponseLength);

  guIAPReceiveFirstBytes = FALSE;
  gIAPCmdTimeout = IAP_CMD_TIMEOUT_DISABLE;
}

/*********************************************************************************************************//**
  * @brief  IAP User level send data.
  * @param  puData: Pointer of dada buffer for write
  * @param  uLength: Write length
  * @retval Total length sent by this function
  ***********************************************************************************************************/
u32 IAPUser_SendData(u8 *puData, u32 uLength)
{
  while (UARTM_GetWriteBufferLength(UARTM_CH0) != 0){};
  return UARTM_Write(UARTM_CH0, puData, uLength);
}

/*********************************************************************************************************//**
  * @brief  Show Test menu.
  * @retval None
  ***********************************************************************************************************/
void ShowTestMenu(void)
{
  printf("\r\n\r\n");
  printf(" Application\r\n");
  printf("--------------------------------\r\n");
  printf(" [1] Start IAP mode\r\n");
  printf(" [2] Hello World\r\n");
  printf(" [3] Enable Write Protection\r\n");
  #if (SLAVE_PULL_HANDSHAKE == 1)
  printf(" [4] Start Slave Pull Handshake\r\n");
  #endif
}

/*********************************************************************************************************//**
  * @brief  Function Handler.
  * @param  uCommand
  * @retval None
  ***********************************************************************************************************/
void FunctionHandler(u32 uCommand)
{
  u32 i;

  switch (uCommand)
  {
    case '1':
    {
      /*----------------------------------------------------------------------------------------------------*/
      /* Set BOOT_MODE as BOOT_MODE_IAP and trigger a reset to start IAP mode.                              */
      /*----------------------------------------------------------------------------------------------------*/
      BOOT_MODE = BOOT_MODE_IAP;
      IAPUser_Reset();
      break;
    }
    case '2':
    {
      printf("\r\n");
      for (i = 0; i < 10; i++)
      {
        printf("Hello World %02d!\r\n", i);
      }
      break;
    }
    case '3':
    {
      FLASH_OptionByte Option;
      FLASH_GetOptionByteStatus(&Option);

      if (Option.MainSecurity == ENABLE || Option.OptionProtect == ENABLE)
      {
        printf("Security or Option Protection is enabled. Can not modify Option.\r\n");
      }
      else
      {
        FLASH_EraseOptionByte();
        FLASH_ProgramWordData(OB_PP0, 0x00000000);
        FLASH_ProgramWordData(OB_PP1, 0x00000000);
        FLASH_ProgramWordData(OB_PP2, 0x00000000);
        FLASH_ProgramWordData(OB_PP3, 0x00000000);
        FLASH_ProgramWordData(OB_CHECKSUM, 0x0 + 0x0 + 0x0 + 0x0 + 0xFFFFFFFF);

        printf("Write Protection enabled. Trigger reset to reload Option Byte\r\n");

        NVIC_SystemReset();
      }
      break;
    }
    #if (SLAVE_PULL_HANDSHAKE == 1)
    case '4':
    {
      extern u32 gStartSlavePullHandshake;
      gStartSlavePullHandshake = TRUE;
      break;
    }
    #endif
  }
}

/*********************************************************************************************************//**
  * @brief  Show version.
  * @retval None
  ***********************************************************************************************************/
void IAPUser_ShowVersion(void)
{
  u32 i, len;
  u32 veraddr = IAP_VERFLASH_START;
  u8 ver[12];

  len = rw(veraddr);
  if (len == 0xFFFFFFFF)
  {
    printf("Version invalid!\r\n");
    return;
  }
  len &= 0x0000FFFF;
  if (len > 12)
  {
    printf("Version length invalid!\r\n");
    return;
  }

  printf("Version = ");

  veraddr += 0x4;
  for (i = 0; i < len; i += 4)
  {
    *(u32 *)(&ver[i]) = rw(veraddr + i);
  }

  ver[len] = 0;

  printf("%s\r\n", ver);
}

/*********************************************************************************************************//**
  * @brief  SysTick Configuration.
  * @retval None
  ***********************************************************************************************************/
void SysTick_Configuration(void)
{
  #define TIMER_BASE                    (SystemCoreClock * 1 / 1000)  /* 1 ms                               */

  SYSTICK_ClockSourceConfig(SYSTICK_SRC_FCLK);
  SYSTICK_SetReloadValue(TIMER_BASE);
  SYSTICK_IntConfig(ENABLE);
  SYSTICK_CounterCmd(SYSTICK_COUNTER_CLEAR);
  SYSTICK_CounterCmd(SYSTICK_COUNTER_ENABLE);
}

/*********************************************************************************************************//**
  * @brief  UART Configuration.
  * @retval None
  ***********************************************************************************************************/
void UART_Configuration(void)
{
  /* !!! NOTICE !!!
     Notice that the local variable (structure) did not have an initial value.
     Please confirm that there are no missing members in the parameter settings below in this function.
  */
  USART_InitTypeDef USART_InitStructure;
  #if (HT32_LIB_LITE == 1)
  USART_InitStructure.USART_BaudRateReg = LIBCFG_MAX_SPEED / 1 / 115200;
  #endif
  USART_InitStructure.USART_BaudRate = 115200;
  USART_InitStructure.USART_WordLength = USART_WORDLENGTH_8B;
  USART_InitStructure.USART_StopBits = USART_STOPBITS_1;
  USART_InitStructure.USART_Parity = USART_PARITY_NO;
  USART_InitStructure.USART_Mode = USART_MODE_NORMAL;
  UARTM_Init(UARTM_CH0, &USART_InitStructure, 40);
}

#if (HT32_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Report both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
     Example: printf("Parameter Error: file %s on line %d\r\n", filename, uline);
  */

  while (1)
  {
  }
}
#endif


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
