/*********************************************************************************************************//**
 * @file    IAP_UART/IAP_UART_Slave/Src_IAP/iap_config.h
 * @version $Rev:: 3438         $
 * @date    $Date:: 2025-06-25 #$
 * @brief   The configuration file.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
// <<< Use Configuration Wizard in Context Menu >>>

/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __IAP_CONFIG_H
#define __IAP_CONFIG_H

/* Includes ------------------------------------------------------------------------------------------------*/

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_UART IAP UART
  * @{
  */

/** @addtogroup IAP_UART_Slave IAP UART Slave
  * @{
  */

/** @addtogroup IAP_UART_Slave_IAP IAP Example
  * @{
  */


/* Settings ------------------------------------------------------------------------------------------------*/

/* IAP                                                                                                      */
#define LOADER_VERSION                            (0x100)

//<o0.0> IAP Debug mode
// <i> Enable IAP Debug mode which output debug message to retarget.
#define IAP_DEBUG_MODE                            (0)

//  <h> IAP Security Setting
//      <o0.0> ARC4 Decryption
#define ARC4_DECRYPTION_EN                        (1)
#define ARC4_KEY_LEN                              (32)

//      <o0.0> Command Key
#define COMMAND_KEY_EN                            (1)
#define COMMAND_KEY_LEN                           (64)

//      <o0.0> Digest Check Flow
#define DIGEST_CHECK_EN                           (1)

//      <e0.0> Restraint Programming Flow
//        <o1> Restraint Minimum Erase Size (Unit: KBytes) <1-255>
#define RESTRAINT_PROGRAMMING_FLOW_EN             (1)
#define MINIMUM_ERASE_SIZE                        (4)
//      </e>
//    </h>

//<o0.0> IAP CRC Checking on Boot
#define IAP_CRC_CHECK_EN                          (0)           /* 0: Disable (Default), 1: Enable          */
#define IAP_CRC_MODE                              (1)           /* 1: Hardware CRC, 0: Software CRC         */
#define IAP_CRC_SAVETYPE                          (0)           /* 1: End Address, 0: Length                */
#define IAP_CRC_ADDR                              (0x00000028)  /* Addr for Start AP CRC check (4 Bytes)    */
#define IAP_APEND_ADDR                            (0x00000034)  /* Addr for AP End Address     (4 Bytes)    */
#define IAP_CRC_KEY                               (0x1A0C0000)  /* key for enable Start AP CRC check        */

//    <e0> IAP Command Timeout
//    <i> Entry IAP mode by default, if IAP Loader did not received any valid IAP command after specific timeout time, it starts AP automatically.
//    <o1> IAP Command Timeout Value (ms) <1-5000:1>
#define IAP_TIMEOUT_EN                            (0)
#define IAP_TIMEOUT                               (1500) /* IAP Command timeout based on ms                 */
//    </e>

//    <e0> Start IAP by Double Reset (External nRST)
//    <i> After the processor resets, the IAP mode starts, remaining active for about IAP_DOUBLE_TIMEOUT Time. If press reset again, program will stay in IAP mode.
//    <o1> IAP Command Timeout Value (ms) <1-5000:1>
//    <i> NOTE!!!! If IAP_TIMEOUT_EN is enabled, IAP_DOUBLE_TIMEOUT will be turned off(-1).
//    <i>          IAP_DOUBLE_TIMEOUT will never reset, and reset is controlled by IAP_TIMEOUT instead.
#define IAP_DOUBLE_RESET_EN                       (0)
#define IAP_DOUBLE_TIMEOUT                        (500)  /* IAP double timeout based on ms                  */
//    </e>

//    <e0> Blinking LED in IAP Mode
//    <i> Enable blinking LED in IAP mode.
//    <i> NOTE!!!! This option is only available for certain series.
//    <o1> Blinking frequency (ms) <1-5000:1>
#define IAP_BLINKING_LED_EN                       (0)
#define IAP_BLINKING_LED_FRQ                      (500) /* Based on ms                                      */
//    </e>

//<o0.0> IAP Reduce Loader Size
#define IAP_REDUCE_LOADER_SIZE                    (0)

/*  User Command count                                                                                      */
#define USER_CMD_DEMO                             (0)
#define USER_CMD_COUNT                            (2)

#if (USER_CMD_DEMO == 0)
#undef USER_CMD_COUNT
#define USER_CMD_COUNT                            (0)
#endif

#define EXT_FLASH_ENABLE                          (0)
#define EXT_FLASH_PAGE_SIZE                       (1024 * 4)
#define EXT_FALSH_ADDRESS                         (0x01000000)

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif
