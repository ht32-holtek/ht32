/*********************************************************************************************************//**
 * @file    IAP_UART/IAP_UART_Slave/Src_AP/main.c
 * @version $Rev:: 676          $
 * @date    $Date:: 2025-06-20 #$
 * @brief   The main program of UART IAP example.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "middleware/uart_module.h"
#include "ap_handler.h"
#include "ap_config.h"

/* Dependency check ----------------------------------------------------------------------------------------*/
#if defined(__HT32F490x1_H)
#define MIN_HT32_FWLIB_VER              (0x01001002) //0xmmnnnrrr -> Vm.n.r
#define MIN_HT32_FWLIB_SVN              (0x99)
#endif
#if defined(__HT32F491x3_H)
#define MIN_HT32_FWLIB_VER              (0x01000006) //0xmmnnnrrr -> Vm.n.r
#define MIN_HT32_FWLIB_SVN              (0x154)
#endif
#if defined(__HT32F493x5_H)
#define MIN_HT32_FWLIB_VER              (0x01001009) //0xmmnnnrrr -> Vm.n.r
#define MIN_HT32_FWLIB_SVN              (0x152)
#endif
#include "ht32_dependency.h" // Not exist means the version of HT32 Firmware Library is older than the module required.

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_UART IAP UART
  * @{
  */

/** @addtogroup IAP_UART_Slave IAP UART Slave
  * @{
  */

/** @addtogroup IAP_UART_Slave_AP AP Example
  * @{
  */


/* Private function prototypes -----------------------------------------------------------------------------*/
void SysTick_Configuration(void);
void UxART_Configuration(void);
void UART_Configuration(void);
void ShowTestMenu(void);
void FunctionHandler(u32 uCommand);

void IAPUser_ShowVersion(void);

/* Global variables ----------------------------------------------------------------------------------------*/
__ALIGN4 u8 guIAPCmdBuffer[64];
vs32 gIAPCmdTimeout = IAP_CMD_TIMEOUT_DISABLE;
u8 guIAPReceiveFirstBytes = FALSE;

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{
  nvic_vector_table_set(NVIC_VECTTAB_FLASH, IAP_APFLASH_START);     /* Set the Vector Table Offset          */

  system_clock_config();

  ht32_board_init();

  UxART_Configuration();

  SysTick_Configuration();

  UART_Configuration();

  AP_Init();

  IAPUser_ShowVersion();
  ShowTestMenu();

  while (1)
  {
    IAPUser_CmdProcess();

    if (usart_flag_get(PRINT_UART, USART_RDBF_FLAG) == SET)
    {
      u32 input;
      input = usart_data_receive(PRINT_UART);
      printf("\r\n\r\n");
      FunctionHandler(input);
      ShowTestMenu();
    }
  }
}

/*********************************************************************************************************//**
  * @brief  IAP User level reset.
  * @retval None
  ***********************************************************************************************************/
void IAPUser_Reset(void)
{
  /* Confirm the communication is finished.                                                                 */

  gIAPCmdTimeout = IAP_CMD_TIMEOUT_RESET;

  #if 0 // "uart_module.c" SVN >= 525 required
  while (UARTM_IsTxFinished(UARTM_CH0) == FALSE)
  #else
  while (1)
  #endif
  {
    if (gIAPCmdTimeout <= 0)
    {
      break;
    }
  }

  NVIC_DisableIRQ(HTCFG_UARTM0_IRQn);
  NVIC_SystemReset();
}

/*********************************************************************************************************//**
  * @brief  USB User level command process.
  * @retval None
  ***********************************************************************************************************/
void IAPUser_CmdProcess(void)
{
  u32 uResponseLength;
  u32 uRxindex;

  #if (SLAVE_PULL_HANDSHAKE == 1)
  if (guIAPReceiveFirstBytes == FALSE)
  {
    AP_SlavePullHandshake();
  }
  #endif

  uRxindex = UARTM_GetReadBufferLength(UARTM_CH0);
  if (uRxindex > 0)
  {
    if (guIAPReceiveFirstBytes == FALSE)
    {
      guIAPReceiveFirstBytes = TRUE;
      gIAPCmdTimeout = IAP_CMD_TIMEOUT_BUFFER_RELOAD;
    }
  }

  if (gIAPCmdTimeout == 0)
  {
    /* Timeout, Rest Rxbuffer                                                                               */
    UARTM_DiscardReadBuffer(UARTM_CH0);
    guIAPReceiveFirstBytes = FALSE;
    gIAPCmdTimeout = IAP_CMD_TIMEOUT_DISABLE;
    return;
  }

  if (uRxindex < 64)
  {
    return;
  }

  UARTM_Read(UARTM_CH0, guIAPCmdBuffer, 64);

  uResponseLength = IAP_CMDHandler(guIAPCmdBuffer);

  UARTM_Write(UARTM_CH0, guIAPCmdBuffer, uResponseLength);

  guIAPReceiveFirstBytes = FALSE;
  gIAPCmdTimeout = IAP_CMD_TIMEOUT_DISABLE;
}

/*********************************************************************************************************//**
  * @brief  IAP User level send data.
  * @param  puData: Pointer of dada buffer for write
  * @param  uLength: Write length
  * @retval Total length sent by this function
  ***********************************************************************************************************/
u32 IAPUser_SendData(u8 *puData, u32 uLength)
{
  while (UARTM_GetWriteBufferLength(UARTM_CH0) != 0){};
  return UARTM_Write(UARTM_CH0, puData, uLength);
}

/*********************************************************************************************************//**
  * @brief  Show Test menu.
  * @retval None
  ***********************************************************************************************************/
void ShowTestMenu(void)
{
  printf("\r\n\r\n");
  printf(" Application\r\n");
  printf("--------------------------------\r\n");
  printf(" [1] Start IAP mode\r\n");
  printf(" [2] Hello World\r\n");
  printf(" [3] Enable Write Protection\r\n");
  #if (SLAVE_PULL_HANDSHAKE == 1)
  printf(" [4] Start Slave Pull Handshake\r\n");
  #endif
}

/*********************************************************************************************************//**
  * @brief  Function Handler.
  * @param  uCommand
  * @retval None
  ***********************************************************************************************************/
void FunctionHandler(u32 uCommand)
{
  u32 i;

  switch (uCommand)
  {
    case '1':
    {
      /*----------------------------------------------------------------------------------------------------*/
      /* Set BOOT_MODE as BOOT_MODE_IAP and trigger a reset to start IAP mode.                              */
      /*----------------------------------------------------------------------------------------------------*/
      BOOT_MODE = BOOT_MODE_IAP;
      IAPUser_Reset();
      break;
    }
    case '2':
    {
      printf("\r\n");
      for (i = 0; i < 10; i++)
      {
        printf("Hello World %02d!\r\n", (int)i);
      }
      break;
    }
    case '3':
    {
      if (flash_fap_status_get() == SET)
      {
        printf("Flash Access Protection is enabled. Can not modify user system data.\r\n");
      }
      else
      {
        flash_unlock();

        if(flash_user_system_data_erase() == FLASH_OPERATE_DONE)
        {
          u32 epp = 0xFFFFFFFF;
          if(flash_epp_set(&epp) == FLASH_OPERATE_DONE)
          {
            printf("Write Protection enabled. Trigger reset to reload user system data.\r\n\n");
            NVIC_SystemReset();
          }
          else
          {
            printf("Write Protection enable operation fail.\r\n\n");
          }
        }
        else
        {
          printf("Flash USD erase fail.\r\n\n");
        }
      }

      break;
    }
    #if (SLAVE_PULL_HANDSHAKE == 1)
    case '4':
    {
      extern u32 gStartSlavePullHandshake;
      gStartSlavePullHandshake = TRUE;
      break;
    }
    #endif
  }
}

/*********************************************************************************************************//**
  * @brief  Show version.
  * @retval None
  ***********************************************************************************************************/
void IAPUser_ShowVersion(void)
{
  u32 i, len;
  u32 veraddr = IAP_VERFLASH_START;
  u8 ver[12];

  len = rw(veraddr);
  if (len == 0xFFFFFFFF)
  {
    printf("Version invalid!\r\n");
    return;
  }
  len &= 0x0000FFFF;
  if (len > 256)
  {
    printf("Version length invalid!\r\n");
    return;
  }

  printf("\rVersion = ");

  veraddr += 0x4;
  for (i = 0; i < len; i += 4)
  {
    *(u32 *)(&ver[i]) = rw(veraddr + i);
  }

  ver[len] = 0;

  printf("%s\r\n", ver);
}

/*********************************************************************************************************//**
  * @brief  SysTick Configuration.
  * @retval None
  ***********************************************************************************************************/
void SysTick_Configuration(void)
{
  #define TIMER_BASE                    (SystemCoreClock / 1000)  /* (SystemCoreClock/1000) =  1 ms         */

  SysTick_Config(TIMER_BASE);
}

/*********************************************************************************************************//**
  * @brief  UART Configuration.
  * @retval None
  ***********************************************************************************************************/
void UART_Configuration(void)
{
  /* !!! NOTICE !!!
     Notice that the local variable (structure) did not have an initial value.
     Please confirm that there are no missing members in the parameter settings below in this function.
  */
  #if !defined(HTCFG_BAUD_RATE)
  #define HTCFG_BAUD_RATE    115200
  #endif
  USART_InitTypeDef USART_InitStructure;
  USART_InitStructure.USART_BaudRate = HTCFG_BAUD_RATE;
  USART_InitStructure.USART_WordLength = USART_DATA_8BITS;
  USART_InitStructure.USART_StopBits = USART_STOP_1_BIT;
  USART_InitStructure.USART_Parity = USART_PARITY_NONE;
  UARTM_Init(UARTM_CH0, &USART_InitStructure, 0);
}

/*********************************************************************************************************//**
  * @brief  UxART Configuration for PRINT_UART.
  * @retval None
  ***********************************************************************************************************/
void UxART_Configuration(void)
{
  uart_print_init(115200);

  #if defined(USE_HT32F49041_SK) || defined(USE_HT32F49163_SK)
  // initialize UxART RX MUX config.
  {
    gpio_init_type gpio_init_struct;
    gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
    gpio_init_struct.gpio_out_type = GPIO_OUTPUT_PUSH_PULL;
    gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
    gpio_init_struct.gpio_pins = HTCFG_RX_PIN;
    gpio_init_struct.gpio_pull = GPIO_PULL_UP;
    gpio_init(HTCFG_RX_GPIO, &gpio_init_struct);

    gpio_pin_mux_config(HTCFG_RX_GPIO, HTCFG_RX_PIN_SOURCE, HTCFG_RX_PIN_MUX_NUM);
  }
  #endif

  usart_receiver_enable(PRINT_UART, TRUE);
}


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
