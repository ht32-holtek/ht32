/*********************************************************************************************************//**
 * @file    IAP_UART/IAP_UART_Slave/Src_AP/ap_config.h
 * @version $Rev:: 6693         $
 * @date    $Date:: 2023-01-19 #$
 * @brief   The configuration file.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
// <<< Use Configuration Wizard in Context Menu >>>

/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __AP_CONFIG_H
#define __AP_CONFIG_H

/* Includes ------------------------------------------------------------------------------------------------*/

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_UART IAP UART
  * @{
  */

/** @addtogroup IAP_UART_Slave IAP UART Slave
  * @{
  */

/** @addtogroup IAP_UART_Slave_AP AP Example
  * @{
  */


/* Settings ------------------------------------------------------------------------------------------------*/

//<o0.0> AP Debug mode
// <i> Enable AP Debug mode which output debug message to retarget.
#define AP_DEBUG_MODE                             (0)

//      <o0.0> Command Key
#define COMMAND_KEY_EN                            (1)
#define COMMAND_KEY_LEN                           (64)

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif
