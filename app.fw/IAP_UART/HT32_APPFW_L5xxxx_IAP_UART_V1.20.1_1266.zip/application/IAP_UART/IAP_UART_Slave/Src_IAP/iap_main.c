/*********************************************************************************************************//**
 * @file    IAP_UART/IAP_UART_Slave/Src_IAP/iap_main.c
 * @version $Rev:: 579          $
 * @date    $Date:: 2025-06-04 #$
 * @brief   The main program of UART IAP example.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "middleware/uart_module.h"
#include "iap_handler.h"
#include "iap_config.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_UART IAP UART
  * @{
  */

/** @addtogroup IAP_UART_Slave IAP UART Slave
  * @{
  */

/** @addtogroup IAP_UART_Slave_IAP IAP Example
  * @{
  */


/* Private function prototypes -----------------------------------------------------------------------------*/
void SysTick_Configuration(void);
void UART_Configuration(void);

#if (IAP_BLINKING_LED_EN == 1)
void IAPLED_Configuration(void);
#endif

/* Global variables ----------------------------------------------------------------------------------------*/
#if (IAP_TIMEOUT_EN == 1)
s32 gIAPTimeout = IAP_TIMEOUT;
#endif
#if (IAP_DOUBLE_RESET_EN == 1)
s32 gDoubleTimeout = IAP_DOUBLE_TIMEOUT;
#endif
#if (IAP_BLINKING_LED_EN == 1)
s32 gLEDBlink = IAP_BLINKING_LED_FRQ;
#endif

__ALIGN4 u8 guIAPCmdBuffer[64];
vs32 gIAPCmdTimeout = IAP_CMD_TIMEOUT_DISABLE;
u8 guIAPReceiveFirstBytes = FALSE;

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{
  #if (HTCFG_STACK_USAGE_ANALYSIS == 1)
  /* !!! NOTICE !!!
     Please update the Keil HT32 PACK and HT32 Firmware Library to the latest version to make sure the
     Stack Usage Analysis function works properly.
  */
  /*
    Set HTCFG_STACK_USAGE_ANALYSIS as 1 in the "ht32xxxxxx_conf.h" to enable Stack Usage Analysis feature.
    This feature is only applicable to the Keil MDK-ARM. Please call the "StackUsageAnalysisInit()" function
    in the begin of the "main()".
    The "StackUsageAnalysisInit()" parameter shall be the start address of the vector table.
    Under Keil Debug mode, tick "View > Watch Window > HT32 Stack Usage Analysis" to show the stack usage
    information. Those information is only valid after calling "StackUsageAnalysisInit()" function.
  */
  StackUsageAnalysisInit(0x00000000);
  #endif

  #if (IAP_DEBUG_MODE == 1)
  RETARGET_Configuration();
  #endif

  #if (IAP_REDUCE_LOADER_SIZE == 1)
  HT_CKCU->AHBCCR |= (1 << 13); //Enable CRC IP Clock
  #endif

  IAPUser_BootProcess();

  SysTick_Configuration();

  IAP_Init();

  #if (EXT_FLASH_ENABLE == 1)
  if (SPI_FLASH_Init() == TRUE)
  {
    SPI_FLASH_WriteStatus(0x00);
  }
  #endif

  #if (USER_CMD_DEMO == 1)
  HT32F_DVB_LEDInit(HT_LED1);
  HT32F_DVB_LEDInit(HT_LED2);
  HT32F_DVB_LEDInit(HT_LED3);
  #endif

  #if (IAP_BLINKING_LED_EN == 1)
  IAPLED_Configuration();
  #endif

  UART_Configuration();

  while (1)
  {
    IAPUser_CmdProcess();
  }
}

/*********************************************************************************************************//**
  * @brief  IAP User level boot process.
  * @retval None
  ***********************************************************************************************************/
void IAPUser_BootProcess(void)
{
  #if 0
  /* !!! NOTICE !!!
        Modify it if you want to use another GPIO pin.
  */
  /*--------------------------------------------------------------------------------------------------------*/
  /* Example that using GPIO to force the IAP mode.                                                         */
  /* GPIO = 1: Normal boot flow, GPIO = 0: IAP mode                                                         */
  /*--------------------------------------------------------------------------------------------------------*/
  {
    CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
    CKCUClock.Bit.PA      = 1;
    CKCU_PeripClockConfig(CKCUClock, ENABLE);
  }
  GPIO_DirectionConfig(HT_GPIOA, GPIO_PIN_0, GPIO_DIR_IN);
  GPIO_InputConfig(HT_GPIOA, GPIO_PIN_0, ENABLE);
  if (GPIO_ReadInBit(HT_GPIOA, GPIO_PIN_0) == SET)
  #endif
  {
    #if (IAP_TIMEOUT_EN == 1)
    if (BOOT_MODE == BOOT_MODE_AP)
    {
      /*----------------------------------------------------------------------------------------------------*/
      /* Start user application when                                                                        */
      /*   1. IO = 1 or                                                                                     */
      /*   2. BOOT_MODE == BOOT_MODE_AP (Default IAP) and                                                   */
      /*----------------------------------------------------------------------------------------------------*/
      BOOT_MODE = 0;
      IAP_JumpToAP(IAP_APFLASH_START);
      #if (IAP_DOUBLE_RESET_EN == 1)
      gDoubleTimeout = -1;
      #endif
    }
    #endif
    #if (IAP_DOUBLE_RESET_EN == 1)
    if (BOOT_MODE != BOOT_MODE_AP)
    {
      if ((RSTCU_GetResetFlagStatus(RSTCU_FLAG_EXTRST) == SET) &&
         (RSTCU_GetResetFlagStatus(RSTCU_FLAG_PORST) == RESET))
      {
        /* External IO reset.                                                                               */
        if (HARDWAVE_RESET == HARDWAVE_RESET_FIRST)
        {
          /* The second external IO reset.                                                                  */
          HARDWAVE_RESET = 0;
          gDoubleTimeout = -1;
          #if (IAP_TIMEOUT_EN == 1)
          gIAPTimeout = -1;
          #endif
        }
        else
        {
          /* The first external IO reset, stay in IAP mode.                                                 */
          HARDWAVE_RESET = HARDWAVE_RESET_FIRST;
        }
        BOOT_MODE = BOOT_MODE_IAP;
      }
      RSTCU_ClearResetFlag(RSTCU_FLAG_PORST);
      RSTCU_ClearResetFlag(RSTCU_FLAG_EXTRST);
    }
    #endif
    #if (IAP_TIMEOUT_EN == 0)
    if (BOOT_MODE != BOOT_MODE_IAP)
    {
      /*----------------------------------------------------------------------------------------------------*/
      /* Start user application when BOOT_MODE != BOOT_MODE_IAP (Default AP)                                */
      /*----------------------------------------------------------------------------------------------------*/
      IAP_JumpToAP(IAP_APFLASH_START);
      #if (IAP_TIMEOUT_EN == 1)
      gIAPTimeout = -1;
      #endif
      #if (IAP_DOUBLE_RESET_EN == 1)
      gDoubleTimeout = -1;
      #endif
    }
    #endif
  }

  /*--------------------------------------------------------------------------------------------------------*/
  /* Start IAP mode                                                                                         */
  /*   1. IO = 0 or                                                                                         */
  /*   2. BOOT_MODE = BOOT_MODE_IAP                                                                         */
  /*--------------------------------------------------------------------------------------------------------*/

  BOOT_MODE = 0;
}

/*********************************************************************************************************//**
  * @brief  IAP User level reset.
  * @retval None
  ***********************************************************************************************************/
void IAPUser_Reset(void)
{
  /* Confirm the communication is finished.                                                                 */

  gIAPCmdTimeout = IAP_CMD_TIMEOUT_RESET;

  #if 0 // "uart_module.c" SVN >= 525 required
  while (UARTM_IsTxFinished(UARTM_CH0) == FALSE)
  #else
  while (1)
  #endif
  {
    if (gIAPCmdTimeout <= 0)
    {
      break;
    }
  }

  NVIC_DisableIRQ(HTCFG_UART_IRQn);
  NVIC_SystemReset();
}

/*********************************************************************************************************//**
  * @brief  USB User level command process.
  * @retval None
  ***********************************************************************************************************/
void IAPUser_CmdProcess(void)
{
  u32 uResponseLength;
  u32 uRxindex;

  #if (SLAVE_PULL_HANDSHAKE == 1)
  if (guIAPReceiveFirstBytes == FALSE)
  {
    IAP_SlavePullHandshake();
  }
  #endif

  uRxindex = UARTM_GetReadBufferLength(UARTM_CH0);
  if (uRxindex > 0)
  {
    if (guIAPReceiveFirstBytes == FALSE)
    {
      guIAPReceiveFirstBytes = TRUE;
      gIAPCmdTimeout = IAP_CMD_TIMEOUT_BUFFER_RELOAD;
    }
  }

  if (gIAPCmdTimeout == 0)
  {
    /* Timeout, Rest Rxbuffer                                                                               */
    UARTM_DiscardReadBuffer(UARTM_CH0);
    guIAPReceiveFirstBytes = FALSE;
    gIAPCmdTimeout = IAP_CMD_TIMEOUT_DISABLE;
    return;
  }

  if (uRxindex < 64)
  {
    return;
  }

  UARTM_Read(UARTM_CH0, guIAPCmdBuffer, 64);

  uResponseLength = IAP_CMDHandler(guIAPCmdBuffer);

  UARTM_Write(UARTM_CH0, guIAPCmdBuffer, uResponseLength);

  guIAPReceiveFirstBytes = FALSE;
  gIAPCmdTimeout = IAP_CMD_TIMEOUT_DISABLE;
}

/*********************************************************************************************************//**
  * @brief  IAP User level send data.
  * @param  puData: Pointer of dada buffer for write
  * @param  uLength: Write length
  * @retval Total length sent by this function
  ***********************************************************************************************************/
u32 IAPUser_SendData(u8 *puData, u32 uLength)
{
  while (UARTM_GetWriteBufferLength(UARTM_CH0) != 0){};
  return UARTM_Write(UARTM_CH0, puData, uLength);
}

/*********************************************************************************************************//**
  * @brief  SysTick Configuration.
  * @retval None
  ***********************************************************************************************************/
void SysTick_Configuration(void)
{
  #if (IAP_REDUCE_LOADER_SIZE == 0)
  #define TIMER_BASE                    (SystemCoreClock * 1 / 1000)  /* 1 ms                               */
  #else
  #define TIMER_BASE                    (LIBCFG_MAX_SPEED * 1 / 1000) /* 1 ms                               */
  #endif

  SYSTICK_ClockSourceConfig(SYSTICK_SRC_FCLK);
  SYSTICK_SetReloadValue(TIMER_BASE);
  SYSTICK_IntConfig(ENABLE);
  SYSTICK_CounterCmd(SYSTICK_COUNTER_CLEAR);
  SYSTICK_CounterCmd(SYSTICK_COUNTER_ENABLE);
}

/*********************************************************************************************************//**
  * @brief  UART Configuration.
  * @retval None
  ***********************************************************************************************************/
void UART_Configuration(void)
{
  /* !!! NOTICE !!!
     Notice that the local variable (structure) did not have an initial value.
     Please confirm that there are no missing members in the parameter settings below in this function.
  */
  #if !defined(HTCFG_BAUD_RATE)
  #define HTCFG_BAUD_RATE    115200
  #endif
  USART_InitTypeDef USART_InitStructure;
  #if (HT32_LIB_LITE == 1)
  USART_InitStructure.USART_BaudRateReg = LIBCFG_MAX_SPEED / 1 / HTCFG_BAUD_RATE;
  #else
  USART_InitStructure.USART_BaudRate = HTCFG_BAUD_RATE;
  #endif
  USART_InitStructure.USART_WordLength = USART_WORDLENGTH_8B;
  USART_InitStructure.USART_StopBits = USART_STOPBITS_1;
  USART_InitStructure.USART_Parity = USART_PARITY_NO;
  USART_InitStructure.USART_Mode = USART_MODE_NORMAL;
  UARTM_Init(UARTM_CH0, &USART_InitStructure, 40);
}

#if (IAP_BLINKING_LED_EN == 1)
/*********************************************************************************************************//**
  * @brief  IAP LED Blinking Configuration.
  * @retval None
  ***********************************************************************************************************/
void IAPLED_Configuration(void)
{
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  HTCFG_BLINKING_LED_CLK(CKCUClock) = 1;
  CKCUClock.Bit.AFIO       = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);
  AFIO_GPxConfig(HTCFG_BLINKING_LED_ID, HTCFG_BLINKING_LED_AFIO_PIN, AFIO_FUN_GPIO);
  GPIO_WriteOutBits(HTCFG_BLINKING_LED, HTCFG_BLINKING_LED_GPIO_PIN, SET);
  GPIO_DirectionConfig(HTCFG_BLINKING_LED, HTCFG_BLINKING_LED_GPIO_PIN, GPIO_DIR_OUT);
}
#endif

#if (HT32_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Report both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
     Example: printf("Parameter Error: file %s on line %d\r\n", filename, uline);
  */

  while (1)
  {
  }
}
#endif


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
