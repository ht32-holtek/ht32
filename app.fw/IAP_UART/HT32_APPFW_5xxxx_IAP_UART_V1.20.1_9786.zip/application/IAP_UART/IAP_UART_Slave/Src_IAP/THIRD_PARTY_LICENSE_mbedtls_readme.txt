/*********************************************************************************************************//**
 * @file    THIRD_PARTY_LICENSE_mbedtls_readme.txt
 * @version $Rev:: 481          $
 * @date    $Date:: 2025-07-02 #$
 * @brief   Third-Party Firmware Usage Notice - Mbed TLS Module. (ARC4)
 *************************************************************************************************************

Third-Party Firmware Code Usage Notice - Mbed TLS Module (ARC4)
========================================
This HOLTEK HT32 Firmware Library and HT32 Application Code includes a third-party implementation of the ARC4 (RC4) cipher algorithm sourced from the Mbed TLS cryptographic library.

Firmware Used:
- mbedtls\
  - library\arc4.c
  - include\mbedtls\arc4.h
  - include\mbedtls\check_config.h
  - include\mbedtls\config.h
  - include\mbedtls\platform.h
  - include\mbedtls\platform_time.h

Source:
- mbedtls-mbedtls-2.7.15.zip

License:
This code is licensed under the Apache License, Version 2.0.
A copy of the Apache License 2.0 is included with this distribution (path: "mbedtls\LICENSE").

The ARC4 module is directly integrated into HOLTEK HT32 Firmware Library and HT32 Application Code. We have no changes to the original source files.

For more information about the license, please see: https://www.apache.org/licenses/LICENSE-2.0

Source Code Availability:
- https://github.com/Mbed-TLS/mbedtls
- https://tls.mbed.org
