;********************************************************************************
;* @file        iap.s
;* @version     $Rev:: 8894         $
;* @date        $Date:: 2025-05-26 #$
;* @brief       Include IAP image
;*
;* @note        Copyright (C) Holtek Semiconductor Inc. All rights reserved.
;*
;* <h2><center>&copy; COPYRIGHT Holtek</center></h2>
;*
;********************************************************************************
;*----------- <<< Use Configuration Wizard in Context Menu >>> ------------------
;********************************************************************************
;// <q> Include IAP image into user's application
INCLUDE_IAP      EQU     0

        AREA    IAP, DATA, READONLY

        IF INCLUDE_IAP <> 0
          INCBIN  IAP.bin
        ENDIF

        END
