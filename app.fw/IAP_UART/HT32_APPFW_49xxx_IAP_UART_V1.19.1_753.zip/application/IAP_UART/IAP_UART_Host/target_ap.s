;********************************************************************************
;* @file        target_ap.s
;* @version     $Rev:: 1097         $
;* @date        $Date:: 2015-11-19 #$
;* @brief       Include AP image
;*
;* @note        Copyright (C) Holtek Semiconductor Inc. All rights reserved.
;*
;* <h2><center>&copy; COPYRIGHT Holtek</center></h2>
;*
;********************************************************************************
;*----------- <<< Use Configuration Wizard in Context Menu >>> ------------------
;********************************************************************************

TARGET_CHIP         EQU     0

USER_DEFINE         EQU     0
HT32F49365_95       EQU     32
HT32F49153_63       EQU     34
HT32F49031_41       EQU     40

;============================================================================================================
; !!! NOTICED !!!
; Use plaintext image when #define ARC4_DECRYPTION_EN (0) in "iap_config.h" of IAP_UART_Slave (AP_Plaintext.bin or AP_xxxxx_Plaintext.bin)
; Use encrypted image when #define ARC4_DECRYPTION_EN (1) in "iap_config.h" of IAP_UART_Slave (AP_Encrypt.bin or AP_xxxxx_Encrypt.bin)
;============================================================================================================

        AREA    TARGET_AP, DATA, READONLY

          IF (TARGET_CHIP=USER_DEFINE)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F49365_95)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_49395_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_49395_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F49153_63)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_49163_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_49163_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F49031_41)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_49041_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_49041_Encrypt.bin
          ENDIF

        AREA    TARGET_DIGEST, DATA, READONLY

          IF (TARGET_CHIP=USER_DEFINE)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F49365_95)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_49395_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F49153_63)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_49163_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F49031_41)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_49041_Encrypt_digest.bin
          ENDIF

        END
