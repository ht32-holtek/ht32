/*********************************************************************************************************//**
 * @file    iap_handler.c
 * @version $Rev:: 3338         $
 * @date    $Date:: 2025-06-06 #$
 * @brief   IAP handler
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "middleware/uart_module.h"
#include "iap_handler.h"
#include "iap_crc16.h"
#include "common/ring_buffer.h"

/* Settings ------------------------------------------------------------------------------------------------*/
#define CMD_DEFAULT_TIMEOUT             (500)
#define CMD_HANDSHAKE_TIMEOUT           (1500)

/* Private types -------------------------------------------------------------------------------------------*/
typedef __PACKED_H struct
{
  u8 uCmd;
  u8 uParameter;
  u16 u16CRC;
  u32 u32StartAddr;
  u32 u32Length_EndAddr;
  u8 uData[52];
} __PACKED_F UARTBridge_ISPTypeDef;

/* Private constants ---------------------------------------------------------------------------------------*/
#define ISPIAP_ERASE_CMD                0x00
#define ISPIAP_FLASH_CMD                0x01
#define ISPIAP_CRC_CMD                  0x02
#define ISPIAP_INFO_CMD                 0x03
#define ISPIAP_RESRT_CMD                0x04
#define ISPIAP_EXIT_CMD                 0x05

#define MAX_CMD_LEN                     (64)

/* Private function prototypes -----------------------------------------------------------------------------*/
static void _ISPIAP_ResetCmdData(void);

/* Private macro -------------------------------------------------------------------------------------------*/
#define WAIT_HANDSHAKE_PACKET() \
{ \
  gCmdTimeOut = CMD_HANDSHAKE_TIMEOUT; \
  while (ISPIAP_Handler() == FALSE) \
  { \
    if (gCmdTimeOut == 0) \
    { \
      return ISPIAP_CMD_TIMEOUT; \
    } \
  } \
}

/* Global variables ----------------------------------------------------------------------------------------*/
__ALIGN4 UARTBridge_ISPTypeDef gCMD = {0x00};
const u32 PackTotalSize = sizeof(gCMD);
const u32 PackDataSize  = sizeof(gCMD.uData);

/* !!! NOTICE !!!
   You must change the key! DO NOT use the default one.
   Take your own risk to use the security architecture of this example.
*/
const unsigned char Command_Key[64] = {
  0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
  0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F,
  0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,
  0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F
};
u16 iap_crc = 0;

extern vs32 gCmdTimeOut;
vu32 gbStartCount = FALSE;
vs32 gRxTimeout = -1;

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  UART Bridge Init.
  * @retval None
  ***********************************************************************************************************/
void ISPIAP_UartInit(void)
{
  /* !!! NOTICE !!!
     Notice that the local variable (structure) did not have an initial value.
     Please confirm that there are no missing members in the parameter settings below in this function.
  */
  USART_InitTypeDef USART_InitStructure;
  USART_InitStructure.USART_BaudRate = 115200;
  USART_InitStructure.USART_WordLength = USART_WORDLENGTH_8B;
  USART_InitStructure.USART_StopBits = USART_STOPBITS_1;
  USART_InitStructure.USART_Parity = USART_PARITY_NO;
  USART_InitStructure.USART_Mode = USART_MODE_NORMAL;
  UARTM_Init(UARTM_CH0, &USART_InitStructure, 40);
}

/*********************************************************************************************************//**
  * @brief  Rx process
  * @retval TRUE or FALSE
  ***********************************************************************************************************/
u32 ISPIAP_Handler(void)
{
  u32 uRxindex = UARTM_GetReadBufferLength(UARTM_CH0);
  u8 u8CmdBuffer[MAX_CMD_LEN];
  u16 crc;
  u16 crcValue;

  if (uRxindex > 0)
  {
    if (gbStartCount == FALSE)
    {
      gbStartCount = TRUE;
      gRxTimeout = 200;
    }
  }

  if (gRxTimeout == 0)
  {
    UARTM_DiscardReadBuffer(UARTM_CH0);
    gbStartCount = FALSE;
    gRxTimeout = -1;
    return FALSE;
  }

  if (uRxindex < MAX_CMD_LEN)
  {
    return FALSE;
  }

  UARTM_Read(UARTM_CH0, u8CmdBuffer, MAX_CMD_LEN);

  /*--------------------------------------------------------------------------------------------------------*/
  /* Check CRC value of command packet                                                                      */
  /*--------------------------------------------------------------------------------------------------------*/
  crc = u8CmdBuffer[2] | ((u16)u8CmdBuffer[3] << 8);
  u8CmdBuffer[2] = u8CmdBuffer[3] = 0;
  crcValue = CRC16(0, (u8 *)(&u8CmdBuffer[0]), 64);

  if (crc == crcValue)
  {
    if (u8CmdBuffer[0] == 0xA)
    {
      gbStartCount = FALSE;
      gRxTimeout = -1;
      return TRUE;
    }
  }

  return FALSE;
}

/*********************************************************************************************************//**
  * @brief  Reset Command.
  * @param  uMode: Mode after reset
  *         @arg ISPIAP_RESRT_PAR_RESET_TO_IAP
  *         @arg ISPIAP_RESRT_PAR_RESET_TO_AP
  * @retval ISPIAP_CMD_OK, ISPIAP_CMD_ERROR, ISPIAP_CMD_TIMEOUT
  ***********************************************************************************************************/
u32 ISPIAP_Reset(u32 uMode)
{
  #if (SLAVE_PULL_HANDSHAKE == 1)
  WAIT_HANDSHAKE_PACKET();
  #endif

  gCMD.uCmd = ISPIAP_RESRT_CMD;
  gCMD.uParameter = uMode;
  gCMD.u16CRC = 0;
  gCMD.u32StartAddr = 0;
  gCMD.u32Length_EndAddr = 0;
  _ISPIAP_ResetCmdData();
  gCMD.u16CRC = CRC16(0, (u8 *)(&gCMD), PackTotalSize);
  gCMD.u16CRC = CRC16(gCMD.u16CRC, (u8 *)Command_Key, sizeof(Command_Key));
  UARTM_Write(UARTM_CH0, (u8 *)&gCMD, PackTotalSize);

  #if 0 // Wait Response
  {
  u8 result;
  gCmdTimeOut = CMD_DEFAULT_TIMEOUT;
  while (UARTM_ReadByte(UARTM_CH0, &result) == ERROR)
  {
    if (gCmdTimeOut == 0)
    {
      return ISPIAP_CMD_TIMEOUT;
    }
  }

  if (result != 'O')
  {
    return ISPIAP_CMD_ERROR;
  }
  }
  #endif

  gCmdTimeOut = 500;
  while (gCmdTimeOut != 0);
  ISPIAP_DiscardReadBuffer();
  gRxTimeout = -1;

  return ISPIAP_CMD_OK;
}

/*********************************************************************************************************//**
  * @brief  Get information.
  * @param  buffer: point of data buffer
  * @retval ISPIAP_CMD_OK, ISPIAP_CMD_ERROR, ISPIAP_CMD_TIMEOUT
  ***********************************************************************************************************/
u32 ISPIAP_Info(u8* buffer)
{
  u8 result;
  u8 dataBuff[64];
  int i;

  #if (SLAVE_PULL_HANDSHAKE == 1)
  WAIT_HANDSHAKE_PACKET();
  #endif

  gCMD.uCmd = ISPIAP_INFO_CMD;
  gCMD.uParameter = 0;
  gCMD.u32StartAddr = 0;
  gCMD.u32Length_EndAddr = 0;
  gCMD.u16CRC = 0;
  _ISPIAP_ResetCmdData();
  gCMD.u16CRC = CRC16(0, (u8 *)(&gCMD), PackTotalSize);
  gCMD.u16CRC = CRC16(gCMD.u16CRC, (u8 *)Command_Key, sizeof(Command_Key));
  UARTM_Write(UARTM_CH0, (u8 *)&gCMD, PackTotalSize);

  gCmdTimeOut = CMD_DEFAULT_TIMEOUT;
  while (UARTM_GetReadBufferLength(UARTM_CH0) < 65)
  {
    if (gCmdTimeOut == 0)
    {
      break;
    }
  }
  result = UARTM_Read(UARTM_CH0, dataBuff, sizeof(dataBuff));
  if (result == 0)
  {
    return ISPIAP_CMD_TIMEOUT;
  }
  else if (dataBuff[0] == 'F')
  {
    return ISPIAP_CMD_ERROR;
  }
  for (i = 0; i < 20; i++)
  {
    buffer[i] = dataBuff[i];
  }
  gCmdTimeOut = CMD_DEFAULT_TIMEOUT;
  while (UARTM_ReadByte(UARTM_CH0, &result) == ERROR)
  {
    if (gCmdTimeOut == 0)
    {
      return ISPIAP_CMD_TIMEOUT;
    }
  }

  if (result != 'O')
  {
    return ISPIAP_CMD_ERROR;
  }

  return ISPIAP_CMD_OK;
}

/*********************************************************************************************************//**
  * @brief  Mass/Page Erase.
  * @param  type: Erase type
  *         @arg ISPIAP_ERASE_PAR_MASS_ERASE: Mass Erase (Not support in IAP mode)
  *         @arg ISPIAP_ERASE_PAR_PAGE_ERASE: Page Erase
  * @param  saddr: Start address
  * @param  eaddr: End address
  * @retval ISPIAP_CMD_OK, ISPIAP_CMD_ERROR, ISPIAP_CMD_TIMEOUT
  ***********************************************************************************************************/
u32 ISPIAP_Erase(u32 type, u32 saddr, u32 eaddr)
{
  u8 result;

  #if (SLAVE_PULL_HANDSHAKE == 1)
  WAIT_HANDSHAKE_PACKET();
  #endif

  gCMD.uCmd = ISPIAP_ERASE_CMD;
  gCMD.uParameter = type;
  gCMD.u16CRC = 0;

  if (type == ISPIAP_ERASE_PAR_MASS_ERASE)
  {
    gCMD.u32StartAddr = 0;
    gCMD.u32Length_EndAddr = 0;
  }
  else if (type == ISPIAP_ERASE_PAR_PAGE_ERASE)
  {
    gCMD.u32StartAddr = saddr;
    gCMD.u32Length_EndAddr = eaddr;
  }

  _ISPIAP_ResetCmdData();
  gCMD.u16CRC = CRC16(0, (u8 *)(&gCMD), PackTotalSize);
  gCMD.u16CRC = CRC16(gCMD.u16CRC, (u8 *)Command_Key, sizeof(Command_Key));
  UARTM_Write(UARTM_CH0, (u8 *)&gCMD, PackTotalSize);

  gCmdTimeOut = CMD_DEFAULT_TIMEOUT;
  while (UARTM_ReadByte(UARTM_CH0, &result) == ERROR)
  {
    if (gCmdTimeOut == 0)
    {
      return ISPIAP_CMD_TIMEOUT;
    }
  }

  if (result != 'O')
  {
    return ISPIAP_CMD_ERROR;
  }

  return ISPIAP_CMD_OK;
}

/*********************************************************************************************************//**
  * @brief  Blank check.
  * @param  saddr: Start address
  * @param  eaddr: End address
  * @retval ISPIAP_CMD_OK, ISPIAP_CMD_ERROR, ISPIAP_CMD_TIMEOUT
  ***********************************************************************************************************/
u32 ISPIAP_Blank(u32 saddr, u32 eaddr)
{
  u8 result;

  #if (SLAVE_PULL_HANDSHAKE == 1)
  WAIT_HANDSHAKE_PACKET();
  #endif

  gCMD.uCmd       = ISPIAP_FLASH_CMD;
  gCMD.uParameter = ISPIAP_FLASH_PAR_BLANK;
  gCMD.u16CRC = 0;
  gCMD.u32StartAddr = saddr;
  gCMD.u32Length_EndAddr = eaddr;

  _ISPIAP_ResetCmdData();
  gCMD.u16CRC = CRC16(0, (u8 *)(&gCMD), PackTotalSize);
  gCMD.u16CRC = CRC16(gCMD.u16CRC, (u8 *)Command_Key, sizeof(Command_Key));
  UARTM_Write(UARTM_CH0, (u8 *)&gCMD, PackTotalSize);

  gCmdTimeOut = CMD_DEFAULT_TIMEOUT;
  while (UARTM_ReadByte(UARTM_CH0, &result) == ERROR)
  {
    if (gCmdTimeOut == 0)
    {
      return ISPIAP_CMD_TIMEOUT;
    }
  }

  if (result != 'O')
  {
    return ISPIAP_CMD_ERROR;
  }

  return ISPIAP_CMD_OK;
}

/*********************************************************************************************************//**
  * @brief  Download image for program or verify.
  * @param  type: Program or verify
  *         @arg ISPIAP_FLASH_PAR_VERIFY: Program mode
  *         @arg ISPIAP_FLASH_PAR_PROGRAM: Verify mode
  * @param  saddr: Start address
  * @param  totallen: Image length for program or verify
  * @retval ISPIAP_CMD_OK, ISPIAP_CMD_ERROR, ISPIAP_CMD_TIMEOUT
  ***********************************************************************************************************/
u32 ISPIAP_Porgram(u32 type, u32 saddr, u32 totallen)
{
  u32 *puSource;
  u32 *puDes;
  u32 i;
  u8 result;

  gCMD.uCmd              = ISPIAP_FLASH_CMD;
  gCMD.uParameter        = type;
  gCMD.u32StartAddr      = saddr;
  gCMD.u32Length_EndAddr = gCMD.u32StartAddr + 52 -1;
  puSource = (u32 *)HTCFG_TARGET_AP_IMAGE_ADDR;
  puDes = (u32 *)gCMD.uData;

  while (1)
  {
    _ISPIAP_ResetCmdData();
    for (i = 0; i < PackDataSize/4; i ++)
    {
      puDes[i] = *puSource;
      puSource++;
    }

    gCMD.u16CRC = 0;
    gCMD.u16CRC = CRC16(0, (u8 *)(&gCMD), PackTotalSize);
    gCMD.u16CRC = CRC16(gCMD.u16CRC, (u8 *)Command_Key, sizeof(Command_Key));

    #if (SLAVE_PULL_HANDSHAKE == 1)
    WAIT_HANDSHAKE_PACKET();
    #endif

    UARTM_Write(UARTM_CH0, (u8 *)&gCMD, PackTotalSize);

    gCmdTimeOut = CMD_DEFAULT_TIMEOUT;
    while (UARTM_ReadByte(UARTM_CH0, &result) == ERROR)
    {
      if (gCmdTimeOut == 0)
      {
        return ISPIAP_CMD_TIMEOUT;
      }
    }

    if (result != 'O')
    {
      return ISPIAP_CMD_ERROR;
    }

    if ((gCMD.u32Length_EndAddr + 1) >= (totallen + saddr))
    {
      break;
    }

    gCMD.u32StartAddr += PackDataSize;
    gCMD.u32Length_EndAddr += PackDataSize;

    if (gCMD.u32Length_EndAddr > (saddr + totallen - 1))
    {
      gCMD.u32Length_EndAddr = (saddr + totallen - 1);
    }
  }
  return ISPIAP_CMD_OK;
}

/*********************************************************************************************************//**
  * @brief  Write Version.
  * @param  type: Program or verify
  *         @arg ISPIAP_FLASH_PAR_VERIFY: Program mode
  *         @arg ISPIAP_FLASH_PAR_PROGRAM: Verify mode
  *         @arg ISPIAP_FLASH_PAR_BLANK: Blank check mode
  * @param  version: FW Version
  * @param  length: FW Length
  * @retval ISPIAP_CMD_OK, ISPIAP_CMD_ERROR, ISPIAP_CMD_TIMEOUT
  ***********************************************************************************************************/
u32 ISPIAP_WriteVersion(u32 type, u32 VerAddr, u8* version, u32 length)
{
  u32 i;
  u8 result;

  #if (SLAVE_PULL_HANDSHAKE == 1)
  WAIT_HANDSHAKE_PACKET();
  #endif

  gCMD.uCmd              = ISPIAP_FLASH_CMD;
  gCMD.uParameter        = type;
  gCMD.u32StartAddr      = VerAddr;
  gCMD.u32Length_EndAddr = VerAddr + 4 + length - 1;
  _ISPIAP_ResetCmdData();

  gCMD.uData[0] = length;
  for (i = 0; i < (length + 4); i++)
  {
    gCMD.uData[4 + i] = version[i];
  }
  gCMD.u16CRC = 0;
  gCMD.u16CRC = CRC16(0, (u8 *)(&gCMD), PackTotalSize);
  gCMD.u16CRC = CRC16(gCMD.u16CRC, (u8 *)Command_Key, sizeof(Command_Key));
  UARTM_Write(UARTM_CH0, (u8 *)&gCMD, PackTotalSize);

  gCmdTimeOut = CMD_DEFAULT_TIMEOUT;
  while (UARTM_ReadByte(UARTM_CH0, &result) == ERROR)
  {
    if (gCmdTimeOut == 0)
    {
      return ISPIAP_CMD_TIMEOUT;
    }
  }

  if (result != 'O')
  {
    return ISPIAP_CMD_ERROR;
  }

  return ISPIAP_CMD_OK;
}

/*********************************************************************************************************//**
  * @brief  Read image (minimum 64 Byes).
  * @param  saddr: Start address
  * @param  eaddr: End address
  * @param  buffer: point of data buffer
  * @retval ISPIAP_CMD_OK, ISPIAP_CMD_ERROR, ISPIAP_CMD_TIMEOUT
  ***********************************************************************************************************/
u32 ISPIAP_ReadFlash(u32 saddr, u32 eaddr, u8 *buffer)
{
  u32 readIndex = 0;
  u32 uTotalLength = eaddr - saddr + 1;
  u32 remain = uTotalLength;
  u8 result;

  #if (SLAVE_PULL_HANDSHAKE == 1)
  WAIT_HANDSHAKE_PACKET();
  #endif

  gCMD.uCmd              = ISPIAP_FLASH_CMD;
  gCMD.uParameter        = ISPIAP_FLASH_PAR_READ;
  gCMD.u16CRC            = 0;
  gCMD.u32StartAddr      = saddr;
  gCMD.u32Length_EndAddr = eaddr;
  _ISPIAP_ResetCmdData();
  gCMD.u16CRC = CRC16(0, (u8 *)(&gCMD), PackTotalSize);
  gCMD.u16CRC = CRC16(gCMD.u16CRC, (u8 *)Command_Key, sizeof(Command_Key));
  UARTM_Write(UARTM_CH0, (u8 *)&gCMD, PackTotalSize);

  gCmdTimeOut = CMD_DEFAULT_TIMEOUT;
  while (1)
  {
    readIndex += UARTM_Read(UARTM_CH0, &buffer[readIndex], remain);
    if (readIndex >= uTotalLength)
    {
      break;
    }
    if (gCmdTimeOut == 0)
    {
      return ISPIAP_CMD_TIMEOUT;
    }
    remain = uTotalLength - readIndex;
  }

  gCmdTimeOut = CMD_DEFAULT_TIMEOUT;
  while (UARTM_ReadByte(UARTM_CH0, &result) == ERROR)
  {
    if (gCmdTimeOut == 0)
    {
      return ISPIAP_CMD_TIMEOUT;
    }
  }

  if (result != 'O')
  {
    return ISPIAP_CMD_ERROR;
  }

  return ISPIAP_CMD_OK;
}

/*********************************************************************************************************//**
  * @brief  Calculate CRC value.
  * @param  saddr: Start address
  * @param  length: Length for CRC calculation
  * @param  crc: CRC of AP Image
  * @retval ISPIAP_CMD_OK, ISPIAP_CMD_ERROR, ISPIAP_CMD_TIMEOUT
  ***********************************************************************************************************/
u32 ISPIAP_CRC(u32 saddr, u32 length, u16 *crc)
{
  u8 result;

  #if (SLAVE_PULL_HANDSHAKE == 1)
  WAIT_HANDSHAKE_PACKET();
  #endif

  gCMD.uCmd = ISPIAP_CRC_CMD;
  gCMD.uParameter = 0;
  gCMD.u16CRC = 0;
  gCMD.u32StartAddr = saddr;
  gCMD.u32Length_EndAddr = GET_AP_CODE_SIZE;
  _ISPIAP_ResetCmdData();

  iap_crc = *((u32 *) (HTCFG_TARGET_AP_DIGEST_ADDR));

  gCMD.uData[0] = (u8)iap_crc;
  gCMD.uData[1] = (u8)(iap_crc >> 8);

  gCMD.u16CRC = CRC16(0, (u8 *)(&gCMD), PackTotalSize);
  gCMD.u16CRC = CRC16(gCMD.u16CRC, (u8 *)Command_Key, sizeof(Command_Key));

  UARTM_Write(UARTM_CH0, (u8 *)&gCMD, PackTotalSize);

  gCmdTimeOut = CMD_DEFAULT_TIMEOUT;
  while (UARTM_GetReadBufferLength(UARTM_CH0) < 2)
  {
    if (gCmdTimeOut == 0)
    {
      return ISPIAP_CMD_TIMEOUT;
    }
  }
  UARTM_Read(UARTM_CH0, (u8*)crc, 2);

  gCmdTimeOut = CMD_DEFAULT_TIMEOUT;
  while (UARTM_GetReadBufferLength(UARTM_CH0) < 1)
  {
    if (gCmdTimeOut == 0)
    {
      return ISPIAP_CMD_TIMEOUT;
    }
  }
  UARTM_Read(UARTM_CH0, &result, 1);
  if (result != 'O')
  {
    return ISPIAP_CMD_ERROR;
  }
  return ISPIAP_CMD_OK;
}

/*********************************************************************************************************//**
  * @brief  Exit Loader mode.
  * @retval ISPIAP_CMD_OK, ISPIAP_CMD_ERROR, ISPIAP_CMD_TIMEOUT
  ***********************************************************************************************************/
u32 ISPIAP_Exit(void)
{
  u8 result;

  #if (SLAVE_PULL_HANDSHAKE == 1)
  WAIT_HANDSHAKE_PACKET();
  #endif

  gCMD.uCmd = ISPIAP_EXIT_CMD;
  gCMD.uParameter = 0;
  gCMD.u32StartAddr = 0;
  gCMD.u32Length_EndAddr = 0;
  gCMD.u16CRC = 0;
  _ISPIAP_ResetCmdData();
  gCMD.u16CRC = CRC16(0, (u8 *)(&gCMD), PackTotalSize);
  gCMD.u16CRC = CRC16(gCMD.u16CRC, (u8 *)Command_Key, sizeof(Command_Key));
  UARTM_Write(UARTM_CH0, (u8 *)&gCMD, PackTotalSize);

  gCmdTimeOut = CMD_DEFAULT_TIMEOUT;
  while (UARTM_ReadByte(UARTM_CH0, &result) == ERROR)
  {
    if (gCmdTimeOut == 0)
    {
      return ISPIAP_CMD_TIMEOUT;
    }
  }

  if (result != 'O')
  {
    return ISPIAP_CMD_ERROR;
  }
  return ISPIAP_CMD_OK;
}

/* Private functions ---------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Reset Command Buffer.
  * @retval
  ***********************************************************************************************************/
static void _ISPIAP_ResetCmdData(void)
{
  u32 *pu32Data = (u32*)gCMD.uData;
  vu32 i;
  for (i = 0; i < sizeof(gCMD.uData)/4; i++)
  {
    pu32Data[i] = 0;
  }
}

#if (IAP_DEBUG_MODE == 1)
/*********************************************************************************************************//**
  * @brief  Dump data for debug.
  * @param  memory
  * @param  Len
  * @retval None
  ***********************************************************************************************************/
static void __DBG_IAP_DumpData(uc8 *memory, u32 len)
{
  u32 i;
  for (i = 0; i < len; i++)
  {
    if (i % 8 == 0)
    {
      if (i != 0)
      {
        __DBG_IAPPrintf("\r\n");
      }
      __DBG_IAPPrintf("\t\t");
    }
    __DBG_IAPPrintf("%02X ", *((u8 *)(memory + i)));
  }
  __DBG_IAPPrintf("\r\n");

  return;
}
#endif
