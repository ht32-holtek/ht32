/*********************************************************************************************************//**
 * @file    ht32f490x1_conf.h
 * @version $Rev:: 84          $
 * @date    $Date:: 2025-05-12 #$
 * @brief   ht32f490x1 config header file
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* define to prevent recursive inclusion -------------------------------------*/
#ifndef __HT32F490x1_CONF_H
#define __HT32F490x1_CONF_H

#ifdef __cplusplus
extern "C" {
#endif

/**
  * @brief in the following line adjust the value of high speed external crystal (hext)
  * used in your application
  *
  * tip: to avoid modifying this file each time you need to use different hext, you
  *      can define the hext value in your toolchain compiler preprocessor.
  *
  */
#if !defined  HEXT_VALUE
#define HEXT_VALUE                       ((uint32_t)8000000) /*!< value of the high speed external crystal in hz */
#endif

/**
  * @brief in the following line adjust the high speed external crystal (hext) startup
  * timeout value
  */
#define HEXT_STARTUP_TIMEOUT             ((uint16_t)0x3000)  /*!< time out for hext start up */
#define HICK_VALUE                       ((uint32_t)8000000) /*!< value of the high speed internal clock in hz */
#define LEXT_VALUE                       ((uint32_t)32768)   /*!< value of the low speed external clock in hz */

/* module define -------------------------------------------------------------*/
#define ACC_MODULE_ENABLED
#define CRM_MODULE_ENABLED
#define TMR_MODULE_ENABLED
#define ERTC_MODULE_ENABLED
#define GPIO_MODULE_ENABLED
#define I2C_MODULE_ENABLED
#define CAN_MODULE_ENABLED
#define USB_MODULE_ENABLED
#define USART_MODULE_ENABLED
#define PWC_MODULE_ENABLED
#define ADC_MODULE_ENABLED
#define SPI_MODULE_ENABLED
#define DMA_MODULE_ENABLED
#define DEBUG_MODULE_ENABLED
#define FLASH_MODULE_ENABLED
#define CRC_MODULE_ENABLED
#define WWDT_MODULE_ENABLED
#define WDT_MODULE_ENABLED
#define EXINT_MODULE_ENABLED
#define MISC_MODULE_ENABLED
#define SCFG_MODULE_ENABLED

/* includes ------------------------------------------------------------------*/
#ifdef ACC_MODULE_ENABLED
#include "ht32f490x1_acc.h"
#endif
#ifdef CRM_MODULE_ENABLED
#include "ht32f490x1_crm.h"
#endif
#ifdef CAN_MODULE_ENABLED
#include "ht32f490x1_can.h"
#endif
#ifdef USB_MODULE_ENABLED
#include "ht32f490x1_usb.h"
#endif
#ifdef TMR_MODULE_ENABLED
#include "ht32f490x1_tmr.h"
#endif
#ifdef ERTC_MODULE_ENABLED
#include "ht32f490x1_ertc.h"
#endif
#ifdef GPIO_MODULE_ENABLED
#include "ht32f490x1_gpio.h"
#endif
#ifdef I2C_MODULE_ENABLED
#include "ht32f490x1_i2c.h"
#endif
#ifdef USART_MODULE_ENABLED
#include "ht32f490x1_usart.h"
#endif
#ifdef PWC_MODULE_ENABLED
#include "ht32f490x1_pwc.h"
#endif
#ifdef ADC_MODULE_ENABLED
#include "ht32f490x1_adc.h"
#endif
#ifdef SPI_MODULE_ENABLED
#include "ht32f490x1_spi.h"
#endif
#ifdef DMA_MODULE_ENABLED
#include "ht32f490x1_dma.h"
#endif
#ifdef DEBUG_MODULE_ENABLED
#include "ht32f490x1_debug.h"
#endif
#ifdef FLASH_MODULE_ENABLED
#include "ht32f490x1_flash.h"
#endif
#ifdef CRC_MODULE_ENABLED
#include "ht32f490x1_crc.h"
#endif
#ifdef WWDT_MODULE_ENABLED
#include "ht32f490x1_wwdt.h"
#endif
#ifdef WDT_MODULE_ENABLED
#include "ht32f490x1_wdt.h"
#endif
#ifdef EXINT_MODULE_ENABLED
#include "ht32f490x1_exint.h"
#endif
#ifdef MISC_MODULE_ENABLED
#include "ht32f490x1_misc.h"
#endif
#ifdef SCFG_MODULE_ENABLED
#include "ht32f490x1_scfg.h"
#endif

#ifdef __cplusplus
}
#endif

#endif


