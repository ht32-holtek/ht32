/*********************************************************************************************************//**
 * @file    ht32_misc.h
 * @version $Rev:: 7802         $
 * @date    $Date:: 2024-07-01 #$
 * @brief   All the function prototypes for the miscellaneous firmware library.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __HT32_CM0PLUS_MISC_H
#define __HT32_CM0PLUS_MISC_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"

/** @addtogroup HT32_Peripheral_Driver
  * @{
  */

/** @addtogroup MISC
  * @{
  */


/* Exported constants --------------------------------------------------------------------------------------*/
/** @defgroup MISC_Exported_Constants MISC exported constants
  * @{
  */

/* SysTick clock source                                                                                     */
#define SYSTICK_SRC_STCLK                           ((u32)0xFFFFFFFB)
#define SYSTICK_SRC_FCLK                            ((u32)0x00000004)

/* SysTick counter state                                                                                    */
#define SYSTICK_COUNTER_DISABLE                     ((u32)0xFFFFFFFE)
#define SYSTICK_COUNTER_ENABLE                      ((u32)0x00000001)
#define SYSTICK_COUNTER_CLEAR                       ((u32)0x00000000)

/**
  * @}
  */

/* Exported functions --------------------------------------------------------------------------------------*/
/** @defgroup MISC_Exported_Functions MISC exported functions
  * @{
  */

void SYSTICK_ClockSourceConfig(u32 SysTick_ClockSource);
void SYSTICK_CounterCmd(u32 SysTick_Counter);
void SYSTICK_IntConfig(bool NewState);
void SYSTICK_SetReloadValue(u32 SysTick_Reload);

u16 CRC_CCITT(u16 seed, u8 *buffer, u32 length);

/**
  * @}
  */


/**
  * @}
  */

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif
