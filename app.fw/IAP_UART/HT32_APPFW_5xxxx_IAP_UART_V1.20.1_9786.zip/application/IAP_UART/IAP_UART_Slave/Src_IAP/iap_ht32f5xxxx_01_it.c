/*********************************************************************************************************//**
 * @file    IAP_UART/IAP_UART_Slave/Src_IAP/iap_ht32f5xxxx_01_it.c
 * @version $Rev:: 8927         $
 * @date    $Date:: 2025-05-28 #$
 * @brief   This file provides all interrupt service routine.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "iap_handler.h"
#include "iap_config.h"
#include "ht32_board_config.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_UART IAP UART
  * @{
  */

/** @addtogroup IAP_UART_Slave IAP UART Slave
  * @{
  */

/** @addtogroup IAP_UART_Slave_IAP IAP Example
  * @{
  */


/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
 * @brief   This function handles Hard Fault exception.
 * @retval  None
 ************************************************************************************************************/
void HardFault_Handler(void)
{
  #if 0

  static vu32 gIsContinue = 0;
  /*--------------------------------------------------------------------------------------------------------*/
  /* For development FW, MCU run into the while loop when the hardfault occurred.                           */
  /* 1. Stack Checking                                                                                      */
  /*    When a hard fault exception occurs, MCU push following register into the stack (main or process     */
  /*    stack). Confirm R13(SP) value in the Register Window and typing it to the Memory Windows, you can   */
  /*    check following register, especially the PC value (indicate the last instruction before hard fault).*/
  /*    SP + 0x00    0x04    0x08    0x0C    0x10    0x14    0x18    0x1C                                   */
  /*           R0      R1      R2      R3     R12      LR      PC    xPSR                                   */
  while (gIsContinue == 0)
  {
  }
  /* 2. Step Out to Find the Clue                                                                           */
  /*    Change the variable "gIsContinue" to any other value than zero in a Local or Watch Window, then     */
  /*    step out the HardFault_Handler to reach the first instruction after the instruction which caused    */
  /*    the hard fault.                                                                                     */
  /*--------------------------------------------------------------------------------------------------------*/

  #else

  /*--------------------------------------------------------------------------------------------------------*/
  /* For production FW, you shall consider to reboot the system when hardfault occurred.                    */
  /*--------------------------------------------------------------------------------------------------------*/
  NVIC_SystemReset();

  #endif
}

/*********************************************************************************************************//**
 * @brief  This function handles SysTick Handler.
 * @retval None
 ************************************************************************************************************/
void SysTick_Handler(void)
{
  extern vs32 gIAPCmdTimeout;
  #if IAP_DOUBLE_RESET_EN
  extern s32 gDoubleTimeout;
  #endif
  #if IAP_BLINKING_LED_EN
  extern s32 gLEDBlink;
  #endif

  #if (IAP_TIMEOUT_EN == 1)
  extern s32 gIAPTimeout;
  if (gIAPTimeout > 0)
  {
    gIAPTimeout--;
    if (gIAPTimeout == 0)
    {
      /* Reset to AP mode */
      BOOT_MODE = BOOT_MODE_AP;
      NVIC_DisableIRQ(HTCFG_UART_IRQn);
      NVIC_SystemReset();
    }
  }
  #elif IAP_DOUBLE_RESET_EN
  if (gDoubleTimeout > 0)
  {
    gDoubleTimeout--;
    if(gDoubleTimeout == 0)
    {
      /* Reset to AP mode */
      BOOT_MODE = BOOT_MODE_AP;
      HARDWAVE_RESET = 0;
      NVIC_DisableIRQ(HTCFG_UART_IRQn);
      NVIC_SystemReset();
    }
  }
  #endif

  if (gIAPCmdTimeout > 0)
  {
    gIAPCmdTimeout--;
  }

  #if IAP_BLINKING_LED_EN
  if(gLEDBlink>0)
  {
    gLEDBlink--;
    if(gLEDBlink == 0)
    {
      gLEDBlink = 500;
      HTCFG_BLINKING_LED->DOUTR ^= HTCFG_BLINKING_LED_GPIO_PIN;
    }
  }
  #endif

  #if (SLAVE_PULL_HANDSHAKE == 1)
  {
    extern u32 gSlavePullHandshakeTime;
    if (gSlavePullHandshakeTime > 0)
    {
      gSlavePullHandshakeTime--;
    }
  }
  #endif
}


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
