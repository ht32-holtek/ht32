;/*---------------------------------------------------------------------------------------------------------*/
;/* Holtek Semiconductor Inc.                                                                               */
;/*                                                                                                         */
;/* Copyright (C) Holtek Semiconductor Inc.                                                                 */
;/* All rights reserved.                                                                                    */
;/*                                                                                                         */
;/*-----------------------------------------------------------------------------------------------------------
;  File Name        : image_info.s
;  Version          : $Rev:: 408          $
;  Date             : $Date:: 2025-06-06 #$
;  Description      : Image information.
;-----------------------------------------------------------------------------------------------------------*/

;/* <<< Use Configuration Wizard in Context Menu >>>                                                        */

;//   <o0> Version String Length <0-12:1>
VER_LEN             EQU  6
VER_STR0            EQU  "V"   ; Put "Space" if not use
VER_STR1            EQU  "1"   ; Put "Space" if not use
VER_STR2            EQU  "."   ; Put "Space" if not use
VER_STR3            EQU  "0"   ; Put "Space" if not use
VER_STR4            EQU  "."   ; Put "Space" if not use
VER_STR5            EQU  "0"   ; Put "Space" if not use
VER_STR6            EQU  " "   ; Put "Space" if not use
VER_STR7            EQU  " "   ; Put "Space" if not use
VER_STR8            EQU  " "   ; Put "Space" if not use
VER_STR9            EQU  " "   ; Put "Space" if not use
VER_STR10           EQU  " "   ; Put "Space" if not use
VER_STR11           EQU  " "   ; Put "Space" if not use

HEADER_STR0         EQU  "F"
HEADER_STR1         EQU  "O"

INFO_0              EQU  ((HEADER_STR1:SHL:24) + (HEADER_STR0:SHL:16) + VER_LEN)
INFO_1              EQU  ((VER_STR3:SHL:24)  + (VER_STR2:SHL:16)  + (VER_STR1:SHL:8) + VER_STR0)
INFO_2              EQU  ((VER_STR7:SHL:24)  + (VER_STR6:SHL:16)  + (VER_STR5:SHL:8) + VER_STR4)
INFO_3              EQU  ((VER_STR11:SHL:24) + (VER_STR10:SHL:16) + (VER_STR9:SHL:8) + VER_STR8)

                    ; !!! NOTICE !!!
                    ; You should change the "_HT32FWID" setting in the file "startup_ht32fxxxxx_nn.s"
                    ; if you use the "_Loader_IsAPFWIDVailed()" in the Loader ("loader.c").

INFO_CK             EQU  (INFO_0 + INFO_1 + INFO_2 + INFO_3 + _HT32FWID)

                    DCD  INFO_0                             ; ---, 04, 0x010, Header + Version String Length
                    DCD  INFO_1                             ; ---, 05, 0x014, Version String 0 ~ 3
                    DCD  INFO_2                             ; ---, 06, 0x018, Version String 4 ~ 7
                    DCD  INFO_3                             ; ---, 07, 0x01C, Version String 8 ~ 11
                    DCD  _HT32FWID                          ; ---, 08, 0x020, Chip name
                    DCD  INFO_CK                            ; ---, 09, 0x024, Checksum

                    END
