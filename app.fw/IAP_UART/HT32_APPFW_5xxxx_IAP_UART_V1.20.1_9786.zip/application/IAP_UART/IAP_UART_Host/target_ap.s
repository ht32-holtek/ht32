;********************************************************************************
;* @file        target_ap.s
;* @version     $Rev:: 8924         $
;* @date        $Date:: 2025-05-28 #$
;* @brief       Include AP image
;*
;* @note        Copyright (C) Holtek Semiconductor Inc. All rights reserved.
;*
;* <h2><center>&copy; COPYRIGHT Holtek</center></h2>
;*
;********************************************************************************
;*----------- <<< Use Configuration Wizard in Context Menu >>> ------------------
;********************************************************************************

TARGET_CHIP         EQU     0

USER_DEFINE         EQU     0
HT32F52220_30       EQU     1
HT32F52231_41       EQU     2
HT32F52331_41       EQU     3
HT32F52342_52       EQU     4
HT32F52243_53       EQU     5
HT32F0008           EQU     6
HT32F52344_54       EQU     9
HT32F57331_41       EQU     13
HT32F57342_52       EQU     14
HT32F54231_41       EQU     19
HT32F54243_53       EQU     20
HT32F50442_52       EQU     26
HT32F53242_52       EQU     28
HT32F53231_41       EQU     29
HT32F50431_41       EQU     30
HT32F52234_44       EQU     33

;============================================================================================================
; !!! NOTICED !!!
; Use plaintext image when #define ARC4_DECRYPTION_EN (0) in "iap_config.h" of IAP_UART_Slave (AP_Plaintext.bin or AP_xxxxx_Plaintext.bin)
; Use encrypted image when #define ARC4_DECRYPTION_EN (1) in "iap_config.h" of IAP_UART_Slave (AP_Encrypt.bin or AP_xxxxx_Encrypt.bin)
;============================================================================================================

        AREA    TARGET_AP, DATA, READONLY

          IF (TARGET_CHIP=USER_DEFINE)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F52220_30)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_52230_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_52230_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F52231_41)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_52241_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_52241_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F52331_41)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_52341_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_52341_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F52342_52)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_52352_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_52352_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F52243_53)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_52253_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_52253_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F0008)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_0008_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_0008_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F57331_41)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_57341_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_57341_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F57342_52)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_57352_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_57352_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F54231_41)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_54241_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_54241_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F54243_53)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_54253_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_54253_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F50442_52)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_50452_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_50452_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F53242_52)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_53252_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_53252_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F53231_41)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_53241_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_53241_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F50431_41)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_50441_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_50441_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F52234_44)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_52244_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_52244_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F52344_54)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_52354_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_52354_Encrypt.bin
          ENDIF

        AREA    TARGET_DIGEST, DATA, READONLY

          IF (TARGET_CHIP=USER_DEFINE)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F52220_30)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_52230_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F52231_41)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_52241_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F52331_41)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_52341_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F52342_52)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_52352_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F52243_53)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_52253_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F0008)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_0008_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F57331_41)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_57341_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F57342_52)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_57352_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F54231_41)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_54241_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F54243_53)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_54253_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F50442_52)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_50452_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F53242_52)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_53252_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F53231_41)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_53241_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F50431_41)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_50441_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F52234_44)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_52244_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F52344_54)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_52354_Encrypt_digest.bin
          ENDIF

        END
