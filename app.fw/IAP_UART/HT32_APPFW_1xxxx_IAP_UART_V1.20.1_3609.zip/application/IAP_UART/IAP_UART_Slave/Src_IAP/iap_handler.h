/*********************************************************************************************************//**
 * @file    IAP_UART/IAP_UART_Slave/Src_IAP/iap_handler.h
 * @version $Rev:: 3344         $
 * @date    $Date:: 2025-06-09 #$
 * @brief   The header file of IAP Handler.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
// <<< Use Configuration Wizard in Context Menu >>>
/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __IAP_HANDLER_H
#define __IAP_HANDLER_H

/* Includes ------------------------------------------------------------------------------------------------*/

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_UART IAP UART
  * @{
  */

/** @addtogroup IAP_UART_Slave IAP UART Slave
  * @{
  */

/** @addtogroup IAP_UART_Slave_IAP IAP Example
  * @{
  */


/* Exported constants --------------------------------------------------------------------------------------*/
#define IAP_TIMEOUT_OFF               (-1)

/* Exported functions --------------------------------------------------------------------------------------*/
void IAP_Init(void);
u32 IAP_CMDHandler(u8 *puCmdBuffer);
u32 IAP_Reset(u32 uMode);
u32 IAP_isAPValid(void);
u32 IAP_isVersionValid(void);
u32 IAP_isChecksumValid(void);
void IAP_GoCMD(u32 address);
void IAP_JumpToAP(u32 address);
void IAP_SlavePullHandshake(void);

extern void IAPUser_BootProcess(void);
extern void IAPUser_Reset(void);
extern void IAPUser_CmdProcess(void);
extern u32 IAPUser_SendData(u8 *puData, u32 uLength);


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif
