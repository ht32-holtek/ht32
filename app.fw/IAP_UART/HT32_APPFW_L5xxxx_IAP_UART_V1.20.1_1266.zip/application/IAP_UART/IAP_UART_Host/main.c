/*********************************************************************************************************//**
 * @file    main.c
 * @version $Rev:: 585          $
 * @date    $Date:: 2025-06-06 #$
 * @brief   Main program.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "iap_handler.h"

/* Private function prototypes -----------------------------------------------------------------------------*/
void SysTick_Configuration(void);

void ShowMenu(void);
void FunctionHandler(u32 uCommand);

void FunAuto(void);
void FunAutoExtFlash(void);

u32 FunResetToIAP(void);
u32 FunResetToAP(void);
u32 FunGetInfo(void);
u32 FunGetVersion(void);
u32 FunEraseVersion(void);
u32 FunEraseAP(void);
u32 FunBlankAP(void);
u32 FunProgramAP(void);
u32 FunVerifyAP(void);
u32 FunCRCDigest(void);
u32 FunUpdateVersion(void);

void ShowResult(u32 uResult);

/* Private constants ---------------------------------------------------------------------------------------*/
#if (IAP_TIME_MEASUREMENT == 1)
#define TimeGetTick   Time_GetTick
#else
#define TimeGetTick() (0)
#endif

/* Global variables ----------------------------------------------------------------------------------------*/
u8 InfoBuffer[20];
u32 gTargetMCUPageSize;
u32 gTargetVerAddr;
u32 gTargetAPAddr;
u32 gTargetAPSize;

vs32 gCmdTimeOut;

u32 uTimeTick;
u32 uAutoTimeTick;

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{
  #if (HTCFG_STACK_USAGE_ANALYSIS == 1)
  /* !!! NOTICE !!!
     Please update the Keil HT32 PACK and HT32 Firmware Library to the latest version to make sure the
     Stack Usage Analysis function works properly.
  */
  /*
    Set HTCFG_STACK_USAGE_ANALYSIS as 1 in the "ht32xxxxxx_conf.h" to enable Stack Usage Analysis feature.
    This feature is only applicable to the Keil MDK-ARM. Please call the "StackUsageAnalysisInit()" function
    in the begin of the "main()".
    The "StackUsageAnalysisInit()" parameter shall be the start address of the vector table.
    Under Keil Debug mode, tick "View > Watch Window > HT32 Stack Usage Analysis" to show the stack usage
    information. Those information is only valid after calling "StackUsageAnalysisInit()" function.
  */
  StackUsageAnalysisInit(0x00000000);
  #endif
  gTargetAPSize = GET_AP_CODE_SIZE;

  RETARGET_Configuration();

  SysTick_Configuration();

  #if (IAP_TIME_MEASUREMENT == 1)
  Time_Init();
  #endif

  ISPIAP_UartInit();

  ShowMenu();

  while (1)
  {
    if (ISPIAP_Handler())
    {
      // Received vailed Slave Handshake packet
    }

    if (USART_GetFlagStatus(RETARGET_USART_PORT, USART_FLAG_RXDR) == SET)
    {
      u32 uInput;
      uInput = getchar();
      printf("%c\r\n", uInput);
      FunctionHandler(uInput);
      ShowMenu();
    }
  }
}

/*********************************************************************************************************//**
  * @brief  SysTick Configuration.
  * @retval None
  ***********************************************************************************************************/
void SysTick_Configuration(void)
{
  SYSTICK_ClockSourceConfig(SYSTICK_SRC_STCLK);         /* Default : CK_AHB/8                               */
  SYSTICK_SetReloadValue(SystemCoreClock / 8 / 1000);   /* (CK_AHB/8/1000) = 1 m                            */
  SYSTICK_IntConfig(ENABLE);                            /* Enable SYSTICK Interrupt                         */
  SYSTICK_CounterCmd(SYSTICK_COUNTER_CLEAR);
  SYSTICK_CounterCmd(SYSTICK_COUNTER_ENABLE);
}

/*********************************************************************************************************//**
  * @brief  Show Menu.
  * @retval None
  ***********************************************************************************************************/
void ShowMenu(void)
{
  printf("\n\r\n\r");
  printf("Holtek UART IAP Host Example Code\n\r");
  printf("=============================================\n\r");
  printf(" [0] Update Application automatically\n\r");
  printf("---------------------------------------------\n\r");
  printf(" [I] Reset To IAP\r\n");
  printf(" [A] Reset To AP\r\n");
  printf(" [1] Get Information\n\r");
  printf(" [2] Erase Version\n\r");
  printf(" [3] Erase AP\n\r");
  printf(" [4] Blank Check AP\r\n");
  printf(" [5] Program AP\n\r");
  printf(" [6] Verify AP\r\n");
  printf(" [7] CRC Digest Check\r\n");
  printf(" [8] Update Version\r\n");
  printf(" [9] Get Version\r\n");

  printf("=============================================\n\r");
  printf(" > ");

  return;
}

/*********************************************************************************************************//**
  * @brief  Function Handler.
  * @param  uCommand
  * @retval None
  ***********************************************************************************************************/
void FunctionHandler(u32 uCommand)
{
  switch (uCommand)
  {
    case 'i':
    case 'I':
    {
      FunResetToIAP();
      break;
    }
    case 'a':
    case 'A':
    {
      FunResetToAP();
      break;
    }
    case 'u':
    case 'U':
    {
      uAutoTimeTick = TimeGetTick();
      FunAutoExtFlash();
      printf("\r\nImage Size = %d\r\n", gTargetAPSize);
      IAPTPrintf("Total Time = %d ms\r\n", (u32)TIME_TICK2MS(TIME_TICKDIFF(uAutoTimeTick, TimeGetTick())));
      break;
    }
    case '0':
    {
      uAutoTimeTick = TimeGetTick();
      FunAuto();
      printf("\r\nImage Size = %d\r\n", gTargetAPSize);
      IAPTPrintf("Total Time = %d ms\r\n", (u32)TIME_TICK2MS(TIME_TICKDIFF(uAutoTimeTick, TimeGetTick())));
      break;
    }
    case '1':
    {
      FunGetInfo();
      break;
    }
    case '2':
    {
      FunEraseVersion();
      break;
    }
    case '3':
    {
      FunEraseAP();
      break;
    }
    case '4':
    {
      FunBlankAP();
      break;
    }
    case '5':
    {
      FunProgramAP();
      break;
    }
    case '6':
    {
      FunVerifyAP();
      break;
    }
    case '7':
    {
      FunCRCDigest();
      break;
    }
    case '8':
    {
      FunUpdateVersion();
      break;
    }
    case '9':
    {
      FunGetVersion();
      break;
    }
    default:
    {
      break;
    }
  }
}

/*********************************************************************************************************//**
  * @brief  Update Application automatically.
  * @retval None
  ***********************************************************************************************************/
void FunAuto(void)
{
  /* STEP 0.1 Reset to IAP                                                                                  */
  if (FunResetToIAP() != ISPIAP_CMD_OK)
  {
    return;
  }

  /* STEP 0.2 Wait System Reset                                                                             */
  gCmdTimeOut = 500;
  while (gCmdTimeOut !=0);
  ISPIAP_DiscardReadBuffer();

  /* STEP 1.0 Get Chip Info                                                                                 */
  if (FunGetInfo() != ISPIAP_CMD_OK)
  {
    return;
  }

  /* STEP 2.0 Erase Version Area                                                                            */
  if (FunEraseVersion() != ISPIAP_CMD_OK)
  {
    return;
  }

  /* STEP 3.0 Erase AP Area                                                                                 */
  if (FunEraseAP() != ISPIAP_CMD_OK)
  {
    return;
  }

  #if 1
  if (FunBlankAP() != ISPIAP_CMD_OK)
  {
    return;
  }
  #endif

  /* STEP 4.0 Program AP                                                                                    */
  if (FunProgramAP() != ISPIAP_CMD_OK)
  {
    return;
  }

  /* STEP 5.0 Verify AP                                                                                     */
  if (FunVerifyAP() != ISPIAP_CMD_OK)
  {
    return;
  }

  /* STEP 6.0 CRC Digest                                                                                    */
  if (FunCRCDigest() != ISPIAP_CMD_OK)
  {
    return;
  }

  /* STEP 7.0 Update Version                                                                                */
  if (FunUpdateVersion() != ISPIAP_CMD_OK)
  {
    return;
  }

  /* Reset to AP                                                                                            */
  FunResetToAP();
}

/*********************************************************************************************************//**
  * @brief  Update External Flash automatically.
  * @retval None
  ***********************************************************************************************************/
void FunAutoExtFlash(void)
{
  /* STEP 0.1 Reset to AP                                                                                   */
  if (FunResetToAP() != ISPIAP_CMD_OK)
  {
    return;
  }

  /* STEP 0.2 Wait System Reset                                                                             */
  gCmdTimeOut = 500;
  while (gCmdTimeOut !=0);
  ISPIAP_DiscardReadBuffer();

  /* STEP 1.0 Get Chip Info                                                                                 */
  if (FunGetInfo() != ISPIAP_CMD_OK)
  {
    return;
  }

  /* STEP 2.0 Erase Version Area                                                                            */
  if (FunEraseVersion() != ISPIAP_CMD_OK)
  {
    return;
  }

  /* STEP 3.0 Erase AP Area                                                                                 */
  if (FunEraseAP() != ISPIAP_CMD_OK)
  {
    return;
  }

  #if 1
  if (FunBlankAP() != ISPIAP_CMD_OK)
  {
    return;
  }
  #endif

  /* STEP 4.0 Program AP                                                                                    */
  if (FunProgramAP() != ISPIAP_CMD_OK)
  {
    return;
  }

  /* STEP 5.0 Verify AP                                                                                     */
  if (FunVerifyAP() != ISPIAP_CMD_OK)
  {
    return;
  }

  /* STEP 6.0 CRC Digest                                                                                    */
  if (FunCRCDigest() != ISPIAP_CMD_OK)
  {
    return;
  }

  /* STEP 7.0 Update Version                                                                                */
  if (FunUpdateVersion() != ISPIAP_CMD_OK)
  {
    return;
  }

  /* Reset to AP                                                                                            */
  FunResetToAP();
}

/*********************************************************************************************************//**
  * @brief  Reset to IAP.
  * @retval None
  ***********************************************************************************************************/
u32 FunResetToIAP(void)
{
  u32 uResult;

  printf("  Reset to IAP...");

  uTimeTick = TimeGetTick();
  uResult = ISPIAP_Reset(ISPIAP_RESRT_PAR_RESET_TO_IAP);

  ShowResult(uResult);

  return uResult;
}

/*********************************************************************************************************//**
  * @brief  Reset to AP.
  * @retval None
  ***********************************************************************************************************/
u32 FunResetToAP(void)
{
  u32 uResult;

  printf("  Reset to AP...");

  uTimeTick = TimeGetTick();
  uResult = ISPIAP_Reset(ISPIAP_RESRT_PAR_RESET_TO_AP);

  ShowResult(uResult);

  return uResult;
}

/*********************************************************************************************************//**
  * @brief  Get Information.
  * @retval None
  ***********************************************************************************************************/
u32 FunGetInfo(void)
{
  u32 uResult;
  u32 u32Info[5];

  printf("  Get Information...");

  uTimeTick = TimeGetTick();
  uResult = ISPIAP_Info((u8*)u32Info);
  ShowResult(uResult);

  if (uResult == ISPIAP_CMD_OK)
  {
    printf("\tLoader Mode: \t%X\r\n", u32Info[0] >> 28);
    printf("\tLoader VER.: \tV%X\r\n", (u32Info[0] & 0x0FFFFFFF) >> 16);
    if ((u32Info[0] & 0xFFFF) != 0x0)
    {
      printf("\tChip Name: \tHT32F04%X\r\n", u32Info[0] & 0xFFFF);
    }
    else
    {
      if(u32Info[4] & 0x100000)
      {
        printf("\tChip Name: \tHT32L%04X\r\n", u32Info[4]-0x100000);
      }
      else
      {
        printf("\tChip Name: \tHT32F%04X\r\n", u32Info[4]);
      }
    }
    printf("\tPage Size: \t%d\r\n", u32Info[1] >> 16);
    printf("\tVER. Address: \t0x%08X\r\n", u32Info[3]);
    printf("\tAP Address: \t0x%08X\r\n", u32Info[1] & 0xFFFF);
    printf("\tFlash Num: \t%d\r\n", u32Info[2] >> 16);
    printf("\tPPBIT Num: \t%d\r\n", u32Info[2] & 0xFFFF);

    gTargetMCUPageSize = u32Info[1] >> 16;
    gTargetVerAddr = u32Info[3];
    gTargetAPAddr = u32Info[1] & 0xFFFF;

    uResult = FunGetVersion();
  }

  return uResult;
}

/*********************************************************************************************************//**
  * @brief  Get Version.
  * @retval None
  ***********************************************************************************************************/
u32 FunGetVersion(void)
{
  u32 uResult;
  u32 uVerLen = 0;
  u8 uVerBuffer[64];

  printf("  Get Version...");

  uTimeTick = TimeGetTick();
  if (gTargetVerAddr == 0)
  {
    /*
       Use default Version Address when the Device under AP mode, host can not get Version Address by Get
       information command.
    */
    uResult = ISPIAP_ReadFlash(HTCFG_DEFAULT_VER_ADDR, HTCFG_DEFAULT_VER_ADDR + 64 - 1, (u8 *)&uVerBuffer);
  }
  else
  {
    uResult = ISPIAP_ReadFlash(gTargetVerAddr, gTargetVerAddr + 64 - 1, (u8 *)&uVerBuffer);
  }

  ShowResult(uResult);
  if (uResult == ISPIAP_CMD_OK)
  {
    uVerLen = *((u32 *)(&uVerBuffer[0]));
    printf("\tAP VER. Len: \t%d\r\n", uVerLen);
    printf("\tAP VER.: \t%s\r\n", &uVerBuffer[4]);
  }
  return uResult;
}

/*********************************************************************************************************//**
  * @brief  Erase Version.
  * @retval None
  ***********************************************************************************************************/
u32 FunEraseVersion(void)
{
  u32 uResult;

  printf("  Erase Version...");

  uTimeTick = TimeGetTick();
  uResult = ISPIAP_Erase(ISPIAP_ERASE_PAR_PAGE_ERASE, gTargetVerAddr, gTargetVerAddr + gTargetMCUPageSize - 1);

  ShowResult(uResult);

  return uResult;
}

/*********************************************************************************************************//**
  * @brief  Erase Application.
  * @retval None
  ***********************************************************************************************************/
u32 FunEraseAP(void)
{
  u32 uResult;

  printf("  Erase AP Flash...");

  uTimeTick = TimeGetTick();
  if (gTargetAPSize < MINIMUM_ERASE_SIZE * 1024)
  {
    uResult = ISPIAP_Erase(ISPIAP_ERASE_PAR_PAGE_ERASE, gTargetAPAddr, gTargetAPAddr + (MINIMUM_ERASE_SIZE * 1024) - 1);
  }
  else
  {
    uResult = ISPIAP_Erase(ISPIAP_ERASE_PAR_PAGE_ERASE, gTargetAPAddr, gTargetAPAddr + gTargetAPSize - 1);
  }

  ShowResult(uResult);

  return uResult;
}

/*********************************************************************************************************//**
  * @brief  Blank Application.
  * @retval None
  ***********************************************************************************************************/
u32 FunBlankAP(void)
{
  u32 uResult;

  printf("  Blank CK. AP Flash...");

  uTimeTick = TimeGetTick();
  uResult = ISPIAP_Blank(gTargetAPAddr, gTargetAPAddr + gTargetAPSize - 1);

  ShowResult(uResult);

  return uResult;
}

/*********************************************************************************************************//**
  * @brief  Program Application.
  * @retval None
  ***********************************************************************************************************/
u32 FunProgramAP(void)
{
  u32 uResult;

  printf("  Program AP Flash...");

  uTimeTick = TimeGetTick();
  uResult = ISPIAP_Porgram(ISPIAP_FLASH_PAR_PROGRAM, gTargetAPAddr, gTargetAPSize);

  ShowResult(uResult);

  return uResult;
}

/*********************************************************************************************************//**
  * @brief  Verify Application.
  * @retval None
  ***********************************************************************************************************/
u32 FunVerifyAP(void)
{
  u32 uResult;

  printf("  Verify AP Flash...");

  uTimeTick = TimeGetTick();
  uResult = ISPIAP_Porgram(ISPIAP_FLASH_PAR_VERIFY, gTargetAPAddr, gTargetAPSize);

  ShowResult(uResult);

  return uResult;
}

/*********************************************************************************************************//**
  * @brief  Verify Application.
  * @retval None
  ***********************************************************************************************************/
u32 FunCRCDigest(void)
{
  u32 uResult;
  u16 slave_crc = 0;

  printf("  CRC Digest Check...");

  uTimeTick = TimeGetTick();
  uResult = ISPIAP_CRC(gTargetAPAddr, gTargetAPSize, &slave_crc);

  ShowResult(uResult);

  return uResult;
}

/*********************************************************************************************************//**
  * @brief  Update Version.
  * @retval None
  ***********************************************************************************************************/
u32 FunUpdateVersion(void)
{
  u32 uResult;

  printf("  Program Version...");

  uTimeTick = TimeGetTick();
  uResult = ISPIAP_WriteVersion(ISPIAP_FLASH_PAR_PROGRAM, gTargetVerAddr, (u8*)HTCFG_AP_VERSION, HTCFG_AP_VERSION_SIZE);

  ShowResult(uResult);

  if (uResult != ISPIAP_CMD_OK)
  {
    return uResult;
  }

  printf("  Verify Version...");

  uResult = ISPIAP_WriteVersion(ISPIAP_FLASH_PAR_VERIFY, gTargetVerAddr, (u8*)HTCFG_AP_VERSION, HTCFG_AP_VERSION_SIZE);

  ShowResult(uResult);

  return uResult;
}

/*********************************************************************************************************//**
  * @brief  Show result message.
  * @retval None
  ***********************************************************************************************************/
void ShowResult(u32 uResult)
{
  #if (IAP_TIME_MEASUREMENT == 1)
  if (uResult == ISPIAP_CMD_OK)
    printf("\t\tOK [%d]\r\n", (u32)TIME_TICK2MS(TIME_TICKDIFF(uTimeTick, TimeGetTick())));
  else if (uResult == ISPIAP_CMD_ERROR)
    printf("\t\tERROR [%d]\r\n", (u32)TIME_TICK2MS(TIME_TICKDIFF(uTimeTick, TimeGetTick())));
  else
    printf("\t\tTIME OUT [%d]\r\n", (u32)TIME_TICK2MS(TIME_TICKDIFF(uTimeTick, TimeGetTick())));
  #else
  if (uResult == ISPIAP_CMD_OK)
    printf("\t\tOK\r\n");
  else if (uResult == ISPIAP_CMD_ERROR)
    printf("\t\tERROR\r\n");
  else
    printf("\t\tTIME OUT\r\n");
  #endif
}

#if (HT32_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Report both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
     Example: printf("Parameter Error: file %s on line %d\r\n", filename, uline);
  */

  while (1)
  {
  }
}
#endif
