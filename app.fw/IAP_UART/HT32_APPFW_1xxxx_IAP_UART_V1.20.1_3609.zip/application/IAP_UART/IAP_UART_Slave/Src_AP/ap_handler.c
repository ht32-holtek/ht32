/*********************************************************************************************************//**
 * @file    IAP_UART/IAP_UART_Slave/Src_AP/ap_handler.c
 * @version $Rev:: 3434         $
 * @date    $Date:: 2025-06-25 #$
 * @brief   This file contains AP handler.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"

#include "ap_handler.h"
#include "ap_config.h"
#include "ap_crc16.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_UART IAP UART
  * @{
  */

/** @addtogroup IAP_UART_Slave IAP UART Slave
  * @{
  */

/** @addtogroup IAP_UART_Slave_AP AP Example
  * @{
  */


/* Private types -------------------------------------------------------------------------------------------*/
typedef u32 (*pFunction)(u32, u32, u32);

typedef __PACKED_H struct
{
  u8 uCmd;
  u8 uParameter;
  u16 u16CRC;
  u32 u32StartAddr;
  u32 u32Length_EndAddr;
  u8 uData[52];
} __PACKED_F SlaveHandshake_ISPTypeDef;

/* Private constants ---------------------------------------------------------------------------------------*/
#define __DBG_APPrintf(...)
#define __DBG_AP_DumpData(...)

#if (AP_DEBUG_MODE == 1)
  #undef __DBG_APPrintf
  #undef __DBG_AP_DumpData
  #define __DBG_APPrintf printf
  static void __DBG_AP_DumpData(uc8 *memory, u32 len);
  #warning "================================= AP Debug Mode Warning ================================"
  #warning " 1. AP debug mode has been enable which degrade the performance.                        "
  #warning " 2. Note that print debug message too much may cause the AP command not synchronized.   "
  #warning " 3. After all debug operation is finished, please remember to turn off AP debug mode.   "
  #warning "========================================================================================"
#endif

#define MAX_CMD_LEN             (64)
#define MAX_TOKENS              (3)
#define CMD_COUNT               (6)
#define CMD_PAYLOAD_ADDR        (12)

#define CMD_READ                (2)
#if (SLAVE_PULL_HANDSHAKE == 1)
#define CMD_HANDSHAKE           (0x0A)
#endif

#define CMD_SUCCESS             ('O')
#define CMD_FAILED              ('F')

/* Private function prototypes -----------------------------------------------------------------------------*/
static u32 _IAP_Flash(u32 type, u32 saddr, u32 eaddr);
static u32 _AP_CMD0(u32 type, u32 saddr, u32 eaddr);

/* Global variables ----------------------------------------------------------------------------------------*/
#if (SLAVE_PULL_HANDSHAKE == 1)
u32 gStartSlavePullHandshake = FALSE;
u32 gSlavePullHandshakeTime = 0;
__ALIGN4 SlaveHandshake_ISPTypeDef gSlaveHandshake = {0x00};
#endif

/* Private variables ---------------------------------------------------------------------------------------*/
#if 0
static u8 *gpCmdBuffer;
#endif
static u8 gResponseLength;

static const pFunction pFComHandlerTable[CMD_COUNT] =
{
  (pFunction)_AP_CMD0,
  (pFunction)_IAP_Flash,
  (pFunction)_AP_CMD0,
  (pFunction)_AP_CMD0,
  (pFunction)AP_Reset,
  (pFunction)_AP_CMD0
};

/* Global functions ----------------------------------------------------------------------------------------*/
#if (COMMAND_KEY_EN == 1)
/* !!! NOTICE !!!
   You must change the key! DO NOT use the default one.
   Take your own risk to use the security architecture of this example.
*/
static const unsigned char Command_Key[COMMAND_KEY_LEN] = {
  0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
  0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F,
  0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,
  0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F
};
#endif

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  AP mode initialization.
  * @retval None
  ***********************************************************************************************************/
void AP_Init(void)
{
  #if (AP_DEBUG_MODE == 1)
  RETARGET_Configuration();
  #endif
}

/*********************************************************************************************************//**
  * @brief  IAP command handler.
  * @retval None
  ***********************************************************************************************************/
u32 IAP_CMDHandler(u8 *puCmdBuffer)
{
  u32 u32Parameter[MAX_TOKENS];
  u32 u32CommandExecuteResult;
  u16 crc;
  u16 crcValue;

  #if 0
  gpCmdBuffer = puCmdBuffer;
  #endif
  gResponseLength = 0;

  /*--------------------------------------------------------------------------------------------------------*/
  /* Check CRC value of command packet                                                                      */
  /*--------------------------------------------------------------------------------------------------------*/
  crc = puCmdBuffer[2] | ((u16)puCmdBuffer[3] << 8);
  puCmdBuffer[2] = puCmdBuffer[3] = 0;
  crcValue = CRC16(0, (u8 *)(&puCmdBuffer[0]), 64);

  #if (COMMAND_KEY_EN == 1)
  crcValue = CRC16(crcValue, (u8 *)Command_Key, sizeof(Command_Key));
  #endif

  /*--------------------------------------------------------------------------------------------------------*/
  /* Check command is valid and CRC is correct                                                              */
  /*--------------------------------------------------------------------------------------------------------*/
  if (puCmdBuffer[0] >= CMD_COUNT)
  {
    /*------------------------------------------------------------------------------------------------------*/
    /* Command invalid. Return 'F' and clear command buffer                                                 */
    /*------------------------------------------------------------------------------------------------------*/
    u32CommandExecuteResult = CMD_FAILED;
  }
  else if (crc != crcValue)
  {
    u32CommandExecuteResult = CMD_FAILED;
  }
  else
  {
    /*------------------------------------------------------------------------------------------------------*/
    /* Prepare parameter and execution command                                                              */
    /*------------------------------------------------------------------------------------------------------*/
    u32Parameter[0] = puCmdBuffer[1];
    u32Parameter[1] = *((u32 *)(&(puCmdBuffer[4])));
    u32Parameter[2] = *((u32 *)(&(puCmdBuffer[8])));

    u32CommandExecuteResult = (*pFComHandlerTable[puCmdBuffer[0]])(u32Parameter[0],
                                                                   u32Parameter[1],
                                                                   u32Parameter[2]);
  }

  puCmdBuffer[gResponseLength] = u32CommandExecuteResult;
  gResponseLength++;

  #if (SLAVE_PULL_HANDSHAKE == 1)
  gSlavePullHandshakeTime = 0;
  #endif

  return gResponseLength;
}

#if (SLAVE_PULL_HANDSHAKE == 1)
/*********************************************************************************************************//**
  * @brief  Slave Pull Handshake.
  * @retval None
  ***********************************************************************************************************/
void AP_SlavePullHandshake(void)
{
  if (gStartSlavePullHandshake == TRUE)
  {
    if (gSlavePullHandshakeTime == 0)
    {
      gSlavePullHandshakeTime = 2;

      gSlaveHandshake.uCmd = CMD_HANDSHAKE;
      gSlaveHandshake.uParameter = 0;
      gSlaveHandshake.u16CRC = 0;
      gSlaveHandshake.u32StartAddr = 0;
      gSlaveHandshake.u32Length_EndAddr = 0;
      gSlaveHandshake.u16CRC = CRC16(0, (u8 *)(&gSlaveHandshake), sizeof(gSlaveHandshake));
      IAPUser_SendData((u8 *)&gSlaveHandshake, sizeof(gSlaveHandshake));
    }
  }
}
#endif

/*********************************************************************************************************//**
  * @brief  Reset Command.
  * @param  uMode: Mode after reset
  * @retval CMD_SUCCESS or CMD_FAILED
  ***********************************************************************************************************/
u32 AP_Reset(u32 uMode)
{
  if (uMode == 0)
  {
    BOOT_MODE = BOOT_MODE_AP;
  }
  else
  {
    BOOT_MODE = BOOT_MODE_IAP;
  }

  {
    u8 uData = CMD_SUCCESS;
    IAPUser_SendData(&uData, 1);
  }

  IAPUser_Reset();

  return CMD_SUCCESS;
}

/*********************************************************************************************************//**
  * @brief  Read Flash for Version.
  * @param  type: Command type
  *         @arg CMD_READ: Read mode
  * @param  saddr: Start address
  * @param  eaddr: End address
  * @retval CMD_SUCCESS or CMD_FAILED
  ***********************************************************************************************************/
static u32 _IAP_Flash(u32 type, u32 saddr, u32 eaddr)
{
  #if 0
  u32 *buffer = (u32 *)(&gpCmdBuffer[CMD_PAYLOAD_ADDR]);
  #endif
  u32 data = 0;
  u32 uTxIndex = 0;
  u32 uTxData[16];

  if (type != CMD_READ)
  {
    return CMD_FAILED;
  }

  /*--------------------------------------------------------------------------------------------------------*/
  /* Read !!!(SECURITY ISSUE DO NOT READ Flash OTHER THAN VERSION AREA)!!!                                  */
  /*--------------------------------------------------------------------------------------------------------*/
  while (saddr <= eaddr)
  {
    if (saddr == IAP_VERFLASH_START)
    {
      data = rw(IAP_VERFLASH_START) & 0x0000FFFF;
    }
    else if (saddr == (IAP_VERFLASH_START + 4))
    {
      data = rw(IAP_VERFLASH_START + 4);
    }
    else if (saddr == (IAP_VERFLASH_START + 8))
    {
      data = rw(IAP_VERFLASH_START + 8);
    }
    else if (saddr == (IAP_VERFLASH_START + 12))
    {
      data = rw(IAP_VERFLASH_START + 12);
    }
    else
    {
      data = 0;
    }

    uTxData[uTxIndex] = data;
    uTxIndex++;

    if ((uTxIndex  == 16) || ((saddr + 4) > eaddr))
    {
      uTxIndex = 0;

      IAPUser_SendData((u8 *)uTxData, 64);
    }
    saddr += 4;
  }

  return CMD_SUCCESS;
}

/* Private functions ---------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  _AP_CMD0.
  * @param  type: TBD
  *         @arg TBD
  *         @arg TBD
  * @param  saddr: Start address
  * @param  eaddr: End address
  * @retval CMD_SUCCESS or CMD_FAILED
  ***********************************************************************************************************/
static u32 _AP_CMD0(u32 type, u32 saddr, u32 eaddr)
{
  return CMD_FAILED;
  //return CMD_SUCCESS;
}

#if (AP_DEBUG_MODE == 1)
/*********************************************************************************************************//**
  * @brief  Dump data for debug.
  * @param  memory
  * @param  Len
  * @retval None
  ***********************************************************************************************************/
static void __DBG_AP_DumpData(uc8 *memory, u32 len)
{
  u32 i;
  for (i = 0; i < len; i++)
  {
    if (i % 8 == 0)
    {
      if (i != 0)
      {
        __DBG_APPrintf("\r\n");
      }
      __DBG_APPrintf("\t\t");
    }
    __DBG_APPrintf("%02X ", *((u8 *)(memory + i)));
  }
  __DBG_APPrintf("\r\n");

  return;
}
#endif


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
