/*********************************************************************************************************//**
 * @file    ht32_board_config.h
 * @version $Rev:: 1255         $
 * @date    $Date:: 2026-04-22 #$
 * @brief   The header file of board configuration.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __HT32_BOARD_CONFIG_H
#define __HT32_BOARD_CONFIG_H

#ifdef __cplusplus
 extern "C" {
#endif


/* Settings ------------------------------------------------------------------------------------------------*/
#define HTCFG_TARGET_AP_DIGEST_ADDR               (0x3000)
#define HTCFG_TARGET_AP_IMAGE_ADDR                (0x3200)

#define HTCFG_DEFAULT_VER_ADDR                    (0x2810) // Shall be modified when IAP code size changed.

#define HTCFG_AP_VERSION                          "v2.0.0" // Shall be changed by user each time the AP image updated.
#define HTCFG_AP_VERSION_SIZE                     (sizeof(HTCFG_AP_VERSION) - 1)

#define MINIMUM_ERASE_SIZE                        (4)

#define SLAVE_PULL_HANDSHAKE                      (0)

#define IAP_TIME_MEASUREMENT                      (1)

#if (IAP_TIME_MEASUREMENT == 1)
#define IAPTPrintf   printf
#else
#define IAPTPrintf(...)
#endif

/*----------------------------------------------------------------------------------------------------------*/
/* UART Module Setting                                                                                      */
/*----------------------------------------------------------------------------------------------------------*/
#if defined(USE_HT32L52241_SK)
  #define HTCFG_UARTM_CH0                         USART0
  #define HTCFG_UARTM0_TX_GPIO_PORT               C
  #define HTCFG_UARTM0_TX_GPIO_PIN                4
  #define HTCFG_UARTM0_RX_GPIO_PORT               C
  #define HTCFG_UARTM0_RX_GPIO_PIN                5
  #define HTCFG_UARTM0_TX_BUFFER_SIZE             128
  #define HTCFG_UARTM0_RX_BUFFER_SIZE             128
#endif

#if defined(USE_HT32L52353_SK)
  #define HTCFG_UARTM_CH0                         UART0
  #define HTCFG_UARTM0_TX_GPIO_PORT               C
  #define HTCFG_UARTM0_TX_GPIO_PIN                4
  #define HTCFG_UARTM0_RX_GPIO_PORT               C
  #define HTCFG_UARTM0_RX_GPIO_PIN                5
  #define HTCFG_UARTM0_TX_BUFFER_SIZE             128
  #define HTCFG_UARTM0_RX_BUFFER_SIZE             128
#endif

#ifdef __cplusplus
}
#endif

#endif
